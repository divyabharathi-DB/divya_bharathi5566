import { db } from "./db";
import { ballots } from "@shared/schema";
import { eq } from "drizzle-orm";

export async function initializeDatabase() {
  try {
    // Check if default ballot exists
    const existingBallots = await db.select().from(ballots);
    
    if (existingBallots.length === 0) {
      // Create default ballot
      await db.insert(ballots).values({
        title: "Presidential Election 2024",
        description: "General election for President and local propositions",
        startDate: new Date(Date.now() - 24 * 60 * 60 * 1000), // Started yesterday
        endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Ends in 7 days
        isActive: true,
        candidates: [
          { id: "sarah-johnson", name: "Sarah Johnson", party: "Democratic Party", description: "Healthcare & Education Reform" },
          { id: "michael-chen", name: "Michael Chen", party: "Republican Party", description: "Economic Growth & Security" },
          { id: "elena-rodriguez", name: "Elena Rodriguez", party: "Green Party", description: "Climate Action & Sustainability" }
        ],
      });
      
      console.log("Database initialized with default ballot");
    }
  } catch (error) {
    console.error("Error initializing database:", error);
  }
}