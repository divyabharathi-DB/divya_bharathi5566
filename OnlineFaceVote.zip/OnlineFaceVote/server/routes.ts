import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertVoterSchema, insertBallotSchema, insertVoteSchema, voters } from "@shared/schema";
import { db } from "./db";
import { aiControl } from "./ai-services";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Voter registration
  app.post("/api/voters/register", async (req, res) => {
    try {
      const voterData = insertVoterSchema.parse(req.body);
      
      // Check if voter already exists
      const existingVoter = await storage.getVoterByEmail(voterData.email);
      if (existingVoter) {
        return res.status(400).json({ message: "Voter with this email already exists" });
      }
      
      const existingVoterId = await storage.getVoterByVoterId(voterData.voterId);
      if (existingVoterId) {
        return res.status(400).json({ message: "Voter ID already exists" });
      }
      
      const voter = await storage.createVoter(voterData);
      res.json(voter);
    } catch (error) {
      console.error("Registration error:", error);
      res.status(400).json({ message: "Invalid voter data" });
    }
  });

  // Face recognition setup
  app.post("/api/voters/:id/face-data", async (req, res) => {
    try {
      const voterId = parseInt(req.params.id);
      const { faceData } = req.body;
      
      if (!faceData) {
        return res.status(400).json({ message: "Face data is required" });
      }
      
      const voter = await storage.updateVoterFaceData(voterId, faceData);
      res.json(voter);
    } catch (error) {
      console.error("Face data update error:", error);
      res.status(404).json({ message: "Voter not found" });
    }
  });

  // AI-powered voter verification
  app.post("/api/voters/verify", async (req, res) => {
    try {
      const { voterId, faceData } = req.body;
      
      const voter = await storage.getVoterByVoterId(voterId);
      if (!voter) {
        await storage.createSecurityLog({
          eventType: "Failed Verification",
          userId: voterId,
          details: "Voter ID not found",
          success: false,
        });
        return res.status(404).json({ message: "Voter not found" });
      }
      
      if (voter.hasVoted) {
        return res.status(400).json({ message: "Voter has already voted" });
      }
      
      // AI-powered identity verification
      const aiVerification = await aiControl.verifyVoterIdentity(voterId, faceData);
      
      if (!aiVerification.verified) {
        return res.status(401).json({ 
          message: "AI verification failed",
          details: aiVerification.aiAnalysis,
          riskFactors: aiVerification.riskFactors,
          confidence: aiVerification.confidence
        });
      }
      
      // Additional fraud detection
      const fraudCheck = await aiControl.detectVotingFraud(voterId, {
        rapidSubmission: false,
        unusualLocation: false,
        multipleAttempts: false
      });
      
      if (fraudCheck.fraudRisk === 'HIGH') {
        return res.status(403).json({
          message: "Security alert: High fraud risk detected",
          recommendation: fraudCheck.recommendation,
          alerts: fraudCheck.alerts
        });
      }
      
      res.json({ 
        verified: true, 
        voter,
        aiAnalysis: aiVerification.aiAnalysis,
        confidence: aiVerification.confidence,
        fraudRisk: fraudCheck.fraudRisk,
        securityScore: Math.round((1 - fraudCheck.riskScore) * 100)
      });
    } catch (error) {
      console.error("Verification error:", error);
      res.status(500).json({ message: "Verification failed" });
    }
  });

  // Get active ballots
  app.get("/api/ballots/active", async (req, res) => {
    try {
      const ballots = await storage.getActiveBallots();
      res.json(ballots);
    } catch (error) {
      console.error("Get ballots error:", error);
      res.status(500).json({ message: "Failed to fetch ballots" });
    }
  });

  // Get all ballots (admin)
  app.get("/api/ballots", async (req, res) => {
    try {
      const ballots = await storage.getAllBallots();
      res.json(ballots);
    } catch (error) {
      console.error("Get all ballots error:", error);
      res.status(500).json({ message: "Failed to fetch ballots" });
    }
  });

  // Create ballot (admin)
  app.post("/api/ballots", async (req, res) => {
    try {
      const ballotData = insertBallotSchema.parse(req.body);
      const ballot = await storage.createBallot(ballotData);
      res.json(ballot);
    } catch (error) {
      console.error("Create ballot error:", error);
      res.status(400).json({ message: "Invalid ballot data" });
    }
  });

  // Submit vote
  app.post("/api/votes", async (req, res) => {
    try {
      const voteData = insertVoteSchema.parse(req.body);
      
      // Verify voter hasn't already voted
      const voter = await storage.getVoterById(voteData.voterId);
      if (!voter) {
        return res.status(404).json({ message: "Voter not found" });
      }
      
      if (voter.hasVoted) {
        return res.status(400).json({ message: "Voter has already voted" });
      }
      
      const vote = await storage.createVote(voteData);
      res.json({ success: true, voteId: vote.id });
    } catch (error) {
      console.error("Submit vote error:", error);
      res.status(400).json({ message: "Invalid vote data" });
    }
  });

  // Get vote results for a ballot
  app.get("/api/ballots/:id/results", async (req, res) => {
    try {
      const ballotId = parseInt(req.params.id);
      const ballot = await storage.getBallotById(ballotId);
      
      if (!ballot) {
        return res.status(404).json({ message: "Ballot not found" });
      }
      
      const votes = await storage.getVotesByBallotId(ballotId);
      const counts = await storage.getVoteCountsByBallot(ballotId);
      
      res.json({
        ballot,
        totalVotes: votes.length,
        results: counts,
      });
    } catch (error) {
      console.error("Get results error:", error);
      res.status(500).json({ message: "Failed to fetch results" });
    }
  });

  // Get statistics (admin dashboard)
  app.get("/api/stats", async (req, res) => {
    try {
      const totalVotes = await storage.getTotalVoteCount();
      const activeVoters = await storage.getActiveVoterCount();
      const turnoutRate = await storage.getTurnoutRate();
      
      const totalVoters = await db.select().from(voters);
      
      res.json({
        totalVotes,
        activeVoters,
        turnoutRate,
        registeredVoters: totalVoters.length,
      });
    } catch (error) {
      console.error("Get stats error:", error);
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  // Get security logs (admin)
  app.get("/api/security-logs", async (req, res) => {
    try {
      const logs = await storage.getSecurityLogs();
      res.json(logs);
    } catch (error) {
      console.error("Get security logs error:", error);
      res.status(500).json({ message: "Failed to fetch security logs" });
    }
  });

  // AI Analytics Endpoints
  app.get("/api/ai/insights", async (req, res) => {
    try {
      const insights = await aiControl.generateVotingInsights();
      res.json(insights);
    } catch (error) {
      console.error("AI insights error:", error);
      res.status(500).json({ message: "Failed to generate AI insights" });
    }
  });

  app.get("/api/ai/integrity", async (req, res) => {
    try {
      const integrity = await aiControl.monitorElectionIntegrity();
      res.json(integrity);
    } catch (error) {
      console.error("AI integrity check error:", error);
      res.status(500).json({ message: "Failed to check election integrity" });
    }
  });

  app.post("/api/ai/fraud-check", async (req, res) => {
    try {
      const { voterId, patterns } = req.body;
      const fraudAnalysis = await aiControl.detectVotingFraud(voterId, patterns);
      res.json(fraudAnalysis);
    } catch (error) {
      console.error("AI fraud check error:", error);
      res.status(500).json({ message: "Failed to perform fraud analysis" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
