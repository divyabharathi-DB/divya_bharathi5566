import {
  voters,
  ballots,
  votes,
  securityLogs,
  type Voter,
  type InsertVoter,
  type Ballot,
  type InsertBallot,
  type Vote,
  type InsertVote,
  type SecurityLog,
  type InsertSecurityLog,
  type Candidate,
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Voter operations
  createVoter(voter: InsertVoter): Promise<Voter>;
  getVoterByEmail(email: string): Promise<Voter | undefined>;
  getVoterByVoterId(voterId: string): Promise<Voter | undefined>;
  updateVoterFaceData(id: number, faceData: string): Promise<Voter>;
  markVoterAsVoted(id: number): Promise<Voter>;
  getVoterById(id: number): Promise<Voter | undefined>;
  
  // Ballot operations
  createBallot(ballot: InsertBallot): Promise<Ballot>;
  getAllBallots(): Promise<Ballot[]>;
  getActiveBallots(): Promise<Ballot[]>;
  getBallotById(id: number): Promise<Ballot | undefined>;
  updateBallot(id: number, updates: Partial<InsertBallot>): Promise<Ballot>;
  
  // Vote operations
  createVote(vote: InsertVote): Promise<Vote>;
  getVotesByBallotId(ballotId: number): Promise<Vote[]>;
  getVoteCountsByBallot(ballotId: number): Promise<Record<string, number>>;
  
  // Security log operations
  createSecurityLog(log: InsertSecurityLog): Promise<SecurityLog>;
  getSecurityLogs(): Promise<SecurityLog[]>;
  
  // Statistics
  getTotalVoteCount(): Promise<number>;
  getActiveVoterCount(): Promise<number>;
  getTurnoutRate(): Promise<number>;
}

// DatabaseStorage - PostgreSQL implementation
export class DatabaseStorage implements IStorage {
  async getVoterById(id: number): Promise<Voter | undefined> {
    const [voter] = await db.select().from(voters).where(eq(voters.id, id));
    return voter || undefined;
  }

  async createVoter(insertVoter: InsertVoter): Promise<Voter> {
    const [voter] = await db
      .insert(voters)
      .values({
        ...insertVoter,
        faceData: insertVoter.faceData || null,
      })
      .returning();
    
    await this.createSecurityLog({
      eventType: "Voter Registration",
      userId: voter.voterId,
      details: `New voter registered: ${voter.firstName} ${voter.lastName}`,
      success: true,
    });
    
    return voter;
  }

  async getVoterByEmail(email: string): Promise<Voter | undefined> {
    const [voter] = await db.select().from(voters).where(eq(voters.email, email));
    return voter || undefined;
  }

  async getVoterByVoterId(voterId: string): Promise<Voter | undefined> {
    const [voter] = await db.select().from(voters).where(eq(voters.voterId, voterId));
    return voter || undefined;
  }

  async updateVoterFaceData(id: number, faceData: string): Promise<Voter> {
    const [voter] = await db
      .update(voters)
      .set({ faceData })
      .where(eq(voters.id, id))
      .returning();
    
    if (!voter) throw new Error("Voter not found");
    
    await this.createSecurityLog({
      eventType: "Face Recognition Setup",
      userId: voter.voterId,
      details: "Face recognition data updated",
      success: true,
    });
    
    return voter;
  }

  async markVoterAsVoted(id: number): Promise<Voter> {
    const [voter] = await db
      .update(voters)
      .set({ hasVoted: true })
      .where(eq(voters.id, id))
      .returning();
    
    if (!voter) throw new Error("Voter not found");
    return voter;
  }

  async createBallot(insertBallot: InsertBallot): Promise<Ballot> {
    const result = await db.execute({
      sql: `INSERT INTO ballots (title, description, start_date, end_date, is_active, candidates, created_at) 
            VALUES ($1, $2, $3, $4, $5, $6, NOW()) 
            RETURNING *`,
      args: [
        insertBallot.title,
        insertBallot.description || null,
        insertBallot.startDate,
        insertBallot.endDate,
        insertBallot.isActive ?? true,
        JSON.stringify(insertBallot.candidates)
      ]
    });
    
    const ballot = result.rows[0] as any;
    const parsedBallot: Ballot = {
      ...ballot,
      candidates: JSON.parse(ballot.candidates),
      createdAt: new Date(ballot.created_at),
      startDate: new Date(ballot.start_date),
      endDate: new Date(ballot.end_date),
      isActive: ballot.is_active,
    };
    
    await this.createSecurityLog({
      eventType: "Ballot Created",
      details: `New ballot created: ${parsedBallot.title}`,
      success: true,
    });
    
    return parsedBallot;
  }

  async getAllBallots(): Promise<Ballot[]> {
    return await db.select().from(ballots);
  }

  async getActiveBallots(): Promise<Ballot[]> {
    const now = new Date();
    return await db.select().from(ballots).where(
      eq(ballots.isActive, true)
    );
  }

  async getBallotById(id: number): Promise<Ballot | undefined> {
    const [ballot] = await db.select().from(ballots).where(eq(ballots.id, id));
    return ballot || undefined;
  }

  async updateBallot(id: number, updates: Partial<InsertBallot>): Promise<Ballot> {
    const updateData: any = {};
    
    if (updates.title !== undefined) updateData.title = updates.title;
    if (updates.description !== undefined) updateData.description = updates.description;
    if (updates.startDate !== undefined) updateData.startDate = updates.startDate;
    if (updates.endDate !== undefined) updateData.endDate = updates.endDate;
    if (updates.isActive !== undefined) updateData.isActive = updates.isActive;
    if (updates.candidates !== undefined) updateData.candidates = updates.candidates;
    
    const [ballot] = await db
      .update(ballots)
      .set(updateData)
      .where(eq(ballots.id, id))
      .returning();
    
    if (!ballot) throw new Error("Ballot not found");
    return ballot;
  }

  async createVote(insertVote: InsertVote): Promise<Vote> {
    const [vote] = await db
      .insert(votes)
      .values(insertVote)
      .returning();
    
    await this.markVoterAsVoted(insertVote.voterId);
    
    const voter = await this.getVoterById(insertVote.voterId);
    await this.createSecurityLog({
      eventType: "Vote Submitted",
      userId: voter?.voterId || null,
      details: `Vote submitted for ballot ${insertVote.ballotId}`,
      success: true,
    });
    
    return vote;
  }

  async getVotesByBallotId(ballotId: number): Promise<Vote[]> {
    return await db.select().from(votes).where(eq(votes.ballotId, ballotId));
  }

  async getVoteCountsByBallot(ballotId: number): Promise<Record<string, number>> {
    const voteResults = await this.getVotesByBallotId(ballotId);
    const counts: Record<string, number> = {};
    
    voteResults.forEach(vote => {
      Object.entries(vote.selections as Record<string, string>).forEach(([question, answer]) => {
        const key = `${question}:${answer}`;
        counts[key] = (counts[key] || 0) + 1;
      });
    });
    
    return counts;
  }

  async createSecurityLog(insertLog: InsertSecurityLog): Promise<SecurityLog> {
    const [log] = await db
      .insert(securityLogs)
      .values({
        ...insertLog,
        userId: insertLog.userId || null,
        ipAddress: insertLog.ipAddress || null,
      })
      .returning();
    
    return log;
  }

  async getSecurityLogs(): Promise<SecurityLog[]> {
    return await db.select().from(securityLogs).orderBy(securityLogs.timestamp);
  }

  async getTotalVoteCount(): Promise<number> {
    const result = await db.select().from(votes);
    return result.length;
  }

  async getActiveVoterCount(): Promise<number> {
    // Return current active voters online (simulated)
    return Math.floor(Math.random() * 50) + 100;
  }

  async getTurnoutRate(): Promise<number> {
    const totalVoters = await db.select().from(voters);
    const votedVoters = await db.select().from(voters).where(eq(voters.hasVoted, true));
    
    if (totalVoters.length === 0) return 0;
    return (votedVoters.length / totalVoters.length) * 100;
  }
}

export const storage = new DatabaseStorage();
