import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const voters = pgTable("voters", {
  id: serial("id").primaryKey(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull().unique(),
  voterId: text("voter_id").notNull().unique(),
  address: text("address").notNull(),
  faceData: text("face_data"), // Mock face recognition data
  hasVoted: boolean("has_voted").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const ballots = pgTable("ballots", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  isActive: boolean("is_active").default(true),
  candidates: json("candidates").$type<Candidate[]>().notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const votes = pgTable("votes", {
  id: serial("id").primaryKey(),
  voterId: integer("voter_id").references(() => voters.id).notNull(),
  ballotId: integer("ballot_id").references(() => ballots.id).notNull(),
  selections: json("selections").$type<Record<string, string>>().notNull(),
  submittedAt: timestamp("submitted_at").defaultNow(),
});

export const securityLogs = pgTable("security_logs", {
  id: serial("id").primaryKey(),
  eventType: text("event_type").notNull(),
  userId: text("user_id"),
  details: text("details").notNull(),
  ipAddress: text("ip_address"),
  success: boolean("success").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertVoterSchema = createInsertSchema(voters).omit({
  id: true,
  hasVoted: true,
  createdAt: true,
});

export const insertBallotSchema = createInsertSchema(ballots).omit({
  id: true,
  createdAt: true,
});

export const insertVoteSchema = createInsertSchema(votes).omit({
  id: true,
  submittedAt: true,
});

export const insertSecurityLogSchema = createInsertSchema(securityLogs).omit({
  id: true,
  timestamp: true,
});

export type Voter = typeof voters.$inferSelect;
export type InsertVoter = z.infer<typeof insertVoterSchema>;

export type Ballot = typeof ballots.$inferSelect;
export type InsertBallot = z.infer<typeof insertBallotSchema>;

export type Vote = typeof votes.$inferSelect;
export type InsertVote = z.infer<typeof insertVoteSchema>;

export type SecurityLog = typeof securityLogs.$inferSelect;
export type InsertSecurityLog = z.infer<typeof insertSecurityLogSchema>;

export interface Candidate {
  id: string;
  name: string;
  party: string;
  description?: string;
}
