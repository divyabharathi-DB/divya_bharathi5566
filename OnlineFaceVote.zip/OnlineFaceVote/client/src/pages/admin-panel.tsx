import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Settings, BarChart3, Shield, Plus, Trash2, Check, Brain } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import AIDashboard from "@/components/ai-dashboard";
import type { Ballot, VotingStats, SecurityLogEntry, Candidate } from "@/lib/types";

const ballotSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string().min(1, "End date is required"),
  candidates: z.array(z.object({
    id: z.string(),
    name: z.string(),
    party: z.string(),
    description: z.string().optional(),
  })).min(1, "At least one candidate is required"),
});

type BallotForm = z.infer<typeof ballotSchema>;

export default function AdminPanel() {
  const [candidates, setCandidates] = useState<Candidate[]>([
    { id: "candidate1", name: "", party: "", description: "" }
  ]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<BallotForm>({
    resolver: zodResolver(ballotSchema),
    defaultValues: {
      title: "",
      description: "",
      startDate: "",
      endDate: "",
      candidates: [],
    },
  });

  // Get statistics
  const { data: stats } = useQuery<VotingStats>({
    queryKey: ['/api/stats'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Get all ballots
  const { data: ballots = [] } = useQuery<Ballot[]>({
    queryKey: ['/api/ballots'],
  });

  // Get security logs
  const { data: securityLogs = [] } = useQuery<SecurityLogEntry[]>({
    queryKey: ['/api/security-logs'],
  });

  // Create ballot mutation
  const createBallotMutation = useMutation({
    mutationFn: async (data: Omit<BallotForm, 'candidates'> & { candidates: Candidate[] }) => {
      const ballotData = {
        ...data,
        startDate: new Date(data.startDate),
        endDate: new Date(data.endDate),
        isActive: true,
      };
      const response = await apiRequest('POST', '/api/ballots', ballotData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Ballot Created",
        description: "The ballot has been successfully created.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/ballots'] });
      form.reset();
      setCandidates([{ id: "candidate1", name: "", party: "", description: "" }]);
    },
    onError: () => {
      toast({
        title: "Creation Failed",
        description: "Failed to create ballot. Please try again.",
        variant: "destructive",
      });
    },
  });

  const addCandidate = () => {
    const newId = `candidate${candidates.length + 1}`;
    setCandidates([...candidates, { id: newId, name: "", party: "", description: "" }]);
  };

  const removeCandidate = (id: string) => {
    setCandidates(candidates.filter(c => c.id !== id));
  };

  const updateCandidate = (id: string, field: keyof Candidate, value: string) => {
    setCandidates(candidates.map(c => 
      c.id === id ? { ...c, [field]: value } : c
    ));
  };

  const onSubmit = (data: Omit<BallotForm, 'candidates'>) => {
    const validCandidates = candidates.filter(c => c.name.trim() && c.party.trim());
    if (validCandidates.length === 0) {
      toast({
        title: "No Candidates",
        description: "Please add at least one candidate with name and party.",
        variant: "destructive",
      });
      return;
    }
    
    createBallotMutation.mutate({
      ...data,
      candidates: validCandidates,
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold professional-text mb-4 flex items-center">
          <Settings className="text-blue-600 mr-3 w-8 h-8" />
          Admin Dashboard
        </h1>
        <p className="text-gray-600">Manage elections, ballots, and monitor voting activity</p>
      </div>

      <Tabs defaultValue="ai-control" className="space-y-8">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="ai-control" className="flex items-center space-x-2">
            <Brain className="w-4 h-4" />
            <span>AI Control</span>
          </TabsTrigger>
          <TabsTrigger value="ballots" className="flex items-center space-x-2">
            <Settings className="w-4 h-4" />
            <span>Ballot Management</span>
          </TabsTrigger>
          <TabsTrigger value="monitoring" className="flex items-center space-x-2">
            <BarChart3 className="w-4 h-4" />
            <span>Live Monitoring</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center space-x-2">
            <Shield className="w-4 h-4" />
            <span>Security Logs</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="ai-control">
          <AIDashboard />
        </TabsContent>

        <TabsContent value="ballots">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Create New Ballot */}
            <div className="lg:col-span-2">
              <Card className="voting-card">
                <CardHeader>
                  <CardTitle className="text-xl professional-text">Create New Ballot</CardTitle>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <FormField
                        control={form.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Election Title</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter election title" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="startDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Start Date</FormLabel>
                              <FormControl>
                                <Input type="datetime-local" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="endDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>End Date</FormLabel>
                              <FormControl>
                                <Input type="datetime-local" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Textarea placeholder="Enter election description" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Candidates Section */}
                      <div>
                        <h3 className="text-lg font-medium professional-text mb-4">Candidates</h3>
                        <div className="space-y-4">
                          {candidates.map((candidate) => (
                            <div key={candidate.id} className="flex items-center space-x-4 p-4 border border-gray-200 rounded-lg">
                              <Input
                                placeholder="Candidate name"
                                value={candidate.name}
                                onChange={(e) => updateCandidate(candidate.id, 'name', e.target.value)}
                                className="flex-1"
                              />
                              <Input
                                placeholder="Party/Affiliation"
                                value={candidate.party}
                                onChange={(e) => updateCandidate(candidate.id, 'party', e.target.value)}
                                className="flex-1"
                              />
                              {candidates.length > 1 && (
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => removeCandidate(candidate.id)}
                                  className="text-red-600 hover:text-red-700"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              )}
                            </div>
                          ))}
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={addCandidate}
                          className="mt-3 text-blue-600 hover:text-blue-700"
                        >
                          <Plus className="w-4 h-4 mr-1" />
                          Add Candidate
                        </Button>
                      </div>

                      <div className="flex justify-end space-x-4">
                        <Button type="button" variant="outline">
                          Save Draft
                        </Button>
                        <Button
                          type="submit"
                          className="trust-button"
                          disabled={createBallotMutation.isPending}
                        >
                          <Check className="w-4 h-4 mr-2" />
                          {createBallotMutation.isPending ? "Publishing..." : "Publish Ballot"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </div>

            {/* Active Elections */}
            <div>
              <Card className="voting-card">
                <CardHeader>
                  <CardTitle className="text-xl professional-text">Active Elections</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {ballots.length === 0 ? (
                      <p className="text-gray-500 text-center py-4">No elections found</p>
                    ) : (
                      ballots.map((ballot) => (
                        <div key={ballot.id} className="border border-gray-200 rounded-lg p-4">
                          <h3 className="font-medium professional-text">{ballot.title}</h3>
                          <p className="text-sm text-gray-600 mt-1">
                            {ballot.isActive ? "Active" : "Inactive"}
                          </p>
                          <div className="mt-3 flex justify-between items-center">
                            <Badge variant={ballot.isActive ? "default" : "secondary"}>
                              {ballot.isActive ? "Active" : "Draft"}
                            </Badge>
                            <span className="text-sm text-gray-600">
                              {ballot.candidates.length} candidates
                            </span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="monitoring">
          <div className="grid lg:grid-cols-4 gap-6 mb-8">
            <Card className="voting-card text-center">
              <CardContent className="pt-6">
                <div className="text-3xl font-bold text-blue-600">{stats?.totalVotes || 0}</div>
                <div className="text-sm text-gray-600 mt-1">Total Votes Cast</div>
              </CardContent>
            </Card>
            <Card className="voting-card text-center">
              <CardContent className="pt-6">
                <div className="text-3xl font-bold text-green-600">{stats?.activeVoters || 0}</div>
                <div className="text-sm text-gray-600 mt-1">Active Voters</div>
              </CardContent>
            </Card>
            <Card className="voting-card text-center">
              <CardContent className="pt-6">
                <div className="text-3xl font-bold professional-text">
                  {stats?.turnoutRate ? `${stats.turnoutRate.toFixed(1)}%` : '0%'}
                </div>
                <div className="text-sm text-gray-600 mt-1">Turnout Rate</div>
              </CardContent>
            </Card>
            <Card className="voting-card text-center">
              <CardContent className="pt-6">
                <div className="text-3xl font-bold text-red-600">
                  {securityLogs.filter(log => !log.success).length}
                </div>
                <div className="text-sm text-gray-600 mt-1">Security Alerts</div>
              </CardContent>
            </Card>
          </div>

          <Card className="voting-card">
            <CardHeader>
              <CardTitle className="text-xl professional-text">Real-time Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {securityLogs.slice(0, 10).map((log) => (
                  <div key={log.id} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-b-0">
                    <div className="flex items-center space-x-3">
                      <div className={`w-2 h-2 rounded-full ${
                        log.success 
                          ? log.eventType === 'Vote Submitted' 
                            ? 'bg-green-600' 
                            : 'bg-blue-600'
                          : 'bg-red-600'
                      }`}></div>
                      <span className="text-sm professional-text">
                        {log.eventType}: {log.details}
                      </span>
                    </div>
                    <span className="text-xs text-gray-500">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security">
          <Card className="voting-card">
            <CardHeader>
              <CardTitle className="text-xl professional-text">Security Event Log</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left p-3 font-medium professional-text">Timestamp</th>
                      <th className="text-left p-3 font-medium professional-text">Event Type</th>
                      <th className="text-left p-3 font-medium professional-text">User ID</th>
                      <th className="text-left p-3 font-medium professional-text">Details</th>
                      <th className="text-left p-3 font-medium professional-text">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {securityLogs.map((log) => (
                      <tr key={log.id}>
                        <td className="p-3 text-gray-600">
                          {new Date(log.timestamp).toLocaleString()}
                        </td>
                        <td className="p-3">{log.eventType}</td>
                        <td className="p-3 font-mono">{log.userId || 'Unknown'}</td>
                        <td className="p-3">{log.details}</td>
                        <td className="p-3">
                          <Badge variant={log.success ? "default" : "destructive"}>
                            {log.success ? "Success" : "Failed"}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
