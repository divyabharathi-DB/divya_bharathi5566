import { useQuery } from "@tanstack/react-query";
import { BarChart3, Users, TrendingUp, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import type { BallotResults, VotingStats } from "@/lib/types";

export default function Results() {
  // Get statistics
  const { data: stats } = useQuery<VotingStats>({
    queryKey: ['/api/stats'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Get results for the first ballot (assuming it's the main election)
  const { data: results } = useQuery<BallotResults>({
    queryKey: ['/api/ballots/1/results'],
    refetchInterval: 30000,
  });

  const calculatePercentage = (count: number, total: number) => {
    return total > 0 ? ((count / total) * 100).toFixed(1) : '0.0';
  };

  const getCandidateVotes = (candidateId: string) => {
    if (!results?.results) return 0;
    return results.results[`president:${candidateId}`] || 0;
  };

  const getPropositionVotes = (option: string) => {
    if (!results?.results) return 0;
    return results.results[`proposition12:${option}`] || 0;
  };

  const totalPresidentialVotes = results?.ballot?.candidates.reduce(
    (sum, candidate) => sum + getCandidateVotes(candidate.id), 0
  ) || 0;

  const totalPropositionVotes = getPropositionVotes('yes') + getPropositionVotes('no');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold professional-text mb-4 flex items-center">
          <BarChart3 className="text-blue-600 mr-3 w-8 h-8" />
          Election Results
        </h1>
        <p className="text-gray-600">Live results and voting statistics</p>
      </div>

      {/* Results Summary */}
      <div className="grid lg:grid-cols-4 gap-6 mb-8">
        <Card className="voting-card text-center">
          <CardContent className="pt-6">
            <div className="text-3xl font-bold text-blue-600">{stats?.totalVotes || 0}</div>
            <div className="text-sm text-gray-600 mt-1">Total Votes</div>
          </CardContent>
        </Card>
        <Card className="voting-card text-center">
          <CardContent className="pt-6">
            <div className="text-3xl font-bold professional-text">{stats?.registeredVoters || 0}</div>
            <div className="text-sm text-gray-600 mt-1">Registered Voters</div>
          </CardContent>
        </Card>
        <Card className="voting-card text-center">
          <CardContent className="pt-6">
            <div className="text-3xl font-bold text-green-600">
              {stats?.turnoutRate ? `${stats.turnoutRate.toFixed(1)}%` : '0%'}
            </div>
            <div className="text-sm text-gray-600 mt-1">Turnout</div>
          </CardContent>
        </Card>
        <Card className="voting-card text-center">
          <CardContent className="pt-6">
            <div className="text-3xl font-bold text-red-600">12h 35m</div>
            <div className="text-sm text-gray-600 mt-1">Time Remaining</div>
          </CardContent>
        </Card>
      </div>

      {/* Presidential Results */}
      {results?.ballot && (
        <Card className="voting-card mb-8">
          <CardHeader>
            <CardTitle className="text-2xl professional-text">{results.ballot.title}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {results.ballot.candidates.map((candidate) => {
                const votes = getCandidateVotes(candidate.id);
                const percentage = parseFloat(calculatePercentage(votes, totalPresidentialVotes));
                
                return (
                  <div key={candidate.id} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center">
                          <Users className="text-gray-500 w-6 h-6" />
                        </div>
                        <div>
                          <h3 className="font-medium professional-text">{candidate.name}</h3>
                          <p className="text-sm text-gray-600">{candidate.party}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xl font-bold text-blue-600">{votes} votes</div>
                        <div className="text-sm text-gray-600">{percentage}%</div>
                      </div>
                    </div>
                    <Progress value={percentage} className="h-3" />
                  </div>
                );
              })}
            </div>
            
            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-600 flex items-center">
                <TrendingUp className="w-4 h-4 mr-2" />
                Results update every 30 seconds. Final results will be certified after voting closes.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Proposition Results */}
      <Card className="voting-card">
        <CardHeader>
          <CardTitle className="text-2xl professional-text">Proposition 12: Education Funding</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-green-600 mb-2">
                {calculatePercentage(getPropositionVotes('yes'), totalPropositionVotes)}%
              </div>
              <div className="text-lg font-medium professional-text mb-4">YES</div>
              <div className="text-gray-600">{getPropositionVotes('yes')} votes</div>
              <Progress 
                value={parseFloat(calculatePercentage(getPropositionVotes('yes'), totalPropositionVotes))} 
                className="h-4 mt-4"
              />
            </div>
            
            <div className="text-center">
              <div className="text-4xl font-bold text-red-600 mb-2">
                {calculatePercentage(getPropositionVotes('no'), totalPropositionVotes)}%
              </div>
              <div className="text-lg font-medium professional-text mb-4">NO</div>
              <div className="text-gray-600">{getPropositionVotes('no')} votes</div>
              <Progress 
                value={parseFloat(calculatePercentage(getPropositionVotes('no'), totalPropositionVotes))} 
                className="h-4 mt-4"
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
