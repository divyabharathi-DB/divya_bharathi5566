import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Check, Clock, Shield, Send, User, Camera, Brain } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import FaceCapture from "@/components/face-capture";
import VoteConfirmationModal from "@/components/vote-confirmation-modal";
import AIVerificationStatus from "@/components/ai-verification-status";
import type { VoterRegistration, Ballot, VoteSelections } from "@/lib/types";

const registrationSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Invalid email address"),
  voterId: z.string().min(1, "Voter ID is required"),
  address: z.string().min(1, "Address is required"),
});

type RegistrationForm = z.infer<typeof registrationSchema>;

export default function VoterPortal() {
  const [currentStep, setCurrentStep] = useState<'register' | 'face' | 'vote'>('register');
  const [voter, setVoter] = useState<any>(null);
  const [voteSelections, setVoteSelections] = useState<VoteSelections>({});
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [aiVerification, setAiVerification] = useState<{
    aiAnalysis?: string;
    confidence?: number;
    fraudRisk?: 'LOW' | 'MEDIUM' | 'HIGH';
    securityScore?: number;
  }>({});
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<RegistrationForm>({
    resolver: zodResolver(registrationSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      voterId: "",
      address: "",
    },
  });

  // Get active ballots
  const { data: ballots = [] } = useQuery<Ballot[]>({
    queryKey: ['/api/ballots/active'],
    enabled: currentStep === 'vote',
  });

  const currentBallot = ballots[0]; // Use first active ballot

  // Registration mutation
  const registerMutation = useMutation({
    mutationFn: async (data: RegistrationForm) => {
      const response = await apiRequest('POST', '/api/voters/register', data);
      return response.json();
    },
    onSuccess: (newVoter) => {
      setVoter(newVoter);
      setCurrentStep('face');
      toast({
        title: "Registration Successful",
        description: "Please set up face recognition to continue.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Registration Failed",
        description: error.message || "Please check your information and try again.",
        variant: "destructive",
      });
    },
  });

  // Face data mutation
  const faceDataMutation = useMutation({
    mutationFn: async (faceData: string) => {
      const response = await apiRequest('POST', `/api/voters/${voter.id}/face-data`, { faceData });
      return response.json();
    },
    onSuccess: () => {
      setCurrentStep('vote');
      toast({
        title: "Face Recognition Set Up",
        description: "You can now proceed to vote.",
      });
    },
    onError: () => {
      toast({
        title: "Face Setup Failed",
        description: "Please try capturing your face again.",
        variant: "destructive",
      });
    },
  });

  // Vote submission mutation
  const voteMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/votes', {
        voterId: voter.id,
        ballotId: currentBallot.id,
        selections: voteSelections,
      });
      return response.json();
    },
    onSuccess: () => {
      setShowConfirmation(false);
      toast({
        title: "Vote Submitted Successfully",
        description: "Thank you for participating in the democratic process!",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
    onError: () => {
      toast({
        title: "Vote Submission Failed",
        description: "Please try again or contact support.",
        variant: "destructive",
      });
    },
  });

  const onRegister = (data: RegistrationForm) => {
    registerMutation.mutate(data);
  };

  const onFaceCapture = (faceData: string) => {
    faceDataMutation.mutate(faceData);
  };

  const onSubmitVote = () => {
    if (!currentBallot || Object.keys(voteSelections).length === 0) {
      toast({
        title: "No Selection Made",
        description: "Please make your selections before submitting.",
        variant: "destructive",
      });
      return;
    }
    setShowConfirmation(true);
  };

  const onConfirmVote = () => {
    voteMutation.mutate();
  };

  if (currentStep === 'register') {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <Brain className="text-blue-600 w-12 h-12" />
            <h1 className="text-4xl font-bold professional-text">AI-Powered Secure Voting</h1>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Experience next-generation election security with AI-driven biometric verification, 
            real-time fraud detection, and intelligent monitoring systems
          </p>
          <div className="flex items-center justify-center space-x-6 mt-6">
            <div className="flex items-center space-x-2 text-blue-600">
              <Brain className="w-5 h-5" />
              <span className="text-sm font-medium">AI Security</span>
            </div>
            <div className="flex items-center space-x-2 text-green-600">
              <Shield className="w-5 h-5" />
              <span className="text-sm font-medium">Fraud Detection</span>
            </div>
            <div className="flex items-center space-x-2 text-purple-600">
              <Camera className="w-5 h-5" />
              <span className="text-sm font-medium">Biometric Verified</span>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Registration Form */}
          <Card className="voting-card">
            <CardHeader>
              <CardTitle className="text-2xl professional-text flex items-center">
                <User className="text-blue-600 mr-3 w-6 h-6" />
                Voter Registration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onRegister)} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>First Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter first name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Last Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter last name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="Enter email address" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="voterId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Voter ID Number</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter voter ID" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Address</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Enter full address" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button
                    type="submit"
                    className="w-full trust-button"
                    disabled={registerMutation.isPending}
                  >
                    <Check className="w-4 h-4 mr-2" />
                    {registerMutation.isPending ? "Registering..." : "Register to Vote"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          {/* Information Card */}
          <Card className="voting-card">
            <CardHeader>
              <CardTitle className="text-2xl professional-text flex items-center">
                <Shield className="text-blue-600 mr-3 w-6 h-6" />
                Secure Voting Process
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="text-blue-600 w-12 h-12" />
                </div>
                <h3 className="text-lg font-semibold professional-text mb-2">Your Security Matters</h3>
                <p className="text-gray-600">
                  Our platform uses advanced biometric verification to ensure voting integrity while protecting your privacy.
                </p>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <Check className="text-green-600 w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-medium professional-text">End-to-End Encryption</h4>
                    <p className="text-sm text-gray-600">Your vote is encrypted and anonymous</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <Check className="text-green-600 w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-medium professional-text">Biometric Verification</h4>
                    <p className="text-sm text-gray-600">Face recognition prevents fraud</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <Check className="text-green-600 w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-medium professional-text">Transparent Process</h4>
                    <p className="text-sm text-gray-600">Real-time results and audit trails</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (currentStep === 'face') {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="voting-card">
          <CardHeader>
            <CardTitle className="text-2xl professional-text flex items-center">
              <Camera className="text-blue-600 mr-3 w-6 h-6" />
              Biometric Verification
            </CardTitle>
          </CardHeader>
          <CardContent>
            <FaceCapture onCapture={onFaceCapture} />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (currentStep === 'vote' && currentBallot) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="voting-card mb-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl professional-text flex items-center">
                <Check className="text-blue-600 mr-3 w-6 h-6" />
                Cast Your Vote
              </CardTitle>
              <div className="flex items-center space-x-4">
                <div className="text-sm text-gray-600 flex items-center">
                  <Clock className="w-4 h-4 mr-1" />
                  Time remaining: <span className="font-mono professional-text ml-1">45:23</span>
                </div>
                <div className="bg-green-600 text-white px-3 py-1 rounded-full text-sm flex items-center">
                  <Shield className="w-3 h-3 mr-1" />
                  Verified
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {/* AI Verification Status */}
            <AIVerificationStatus
              aiAnalysis={aiVerification.aiAnalysis}
              confidence={aiVerification.confidence}
              fraudRisk={aiVerification.fraudRisk}
              securityScore={aiVerification.securityScore}
              isVisible={Object.keys(aiVerification).length > 0}
            />

            {/* Traditional Verification Status */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-8">
              <div className="flex items-center">
                <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mr-4">
                  <Brain className="text-white w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-medium professional-text">AI Identity Verified</h3>
                  <p className="text-sm text-gray-600">Advanced biometric analysis confirmed. Fraud protection active.</p>
                  <p className="text-xs text-gray-500 mt-1">
                    Voter ID: <span className="font-mono">{voter?.voterId}</span>
                  </p>
                </div>
              </div>
            </div>

            {/* Ballot */}
            <div className="space-y-8">
              <div className="border border-gray-200 rounded-xl p-6">
                <h3 className="text-xl font-semibold professional-text mb-6">
                  {currentBallot.title}
                </h3>
                <p className="text-gray-600 mb-6">Select one candidate</p>
                
                <RadioGroup
                  value={voteSelections.president || ''}
                  onValueChange={(value) => setVoteSelections(prev => ({ ...prev, president: value }))}
                  className="space-y-4"
                >
                  {currentBallot.candidates.map((candidate) => (
                    <div key={candidate.id} className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
                      <RadioGroupItem value={candidate.id} id={candidate.id} />
                      <div className="flex items-center space-x-4 flex-1">
                        <div className="w-16 h-16 bg-gray-300 rounded-full flex items-center justify-center">
                          <User className="text-gray-500 w-6 h-6" />
                        </div>
                        <div>
                          <Label htmlFor={candidate.id} className="font-medium professional-text cursor-pointer">{candidate.name}</Label>
                          <p className="text-sm text-gray-600">{candidate.party}</p>
                          {candidate.description && (
                            <p className="text-xs text-gray-500">{candidate.description}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              {/* Proposition */}
              <div className="border border-gray-200 rounded-xl p-6">
                <h3 className="text-xl font-semibold professional-text mb-4">
                  Proposition 12: Education Funding
                </h3>
                <p className="text-gray-600 mb-6">
                  Shall the city increase property taxes by 0.5% to fund new school infrastructure and teacher salary improvements?
                </p>
                
                <RadioGroup
                  value={voteSelections.proposition12 || ''}
                  onValueChange={(value) => setVoteSelections(prev => ({ ...prev, proposition12: value }))}
                  className="space-y-3"
                >
                  <div className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                    <RadioGroupItem value="yes" id="prop-yes" />
                    <Label htmlFor="prop-yes" className="professional-text font-medium cursor-pointer">
                      Yes - Support the measure
                    </Label>
                  </div>
                  <div className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                    <RadioGroupItem value="no" id="prop-no" />
                    <Label htmlFor="prop-no" className="professional-text font-medium cursor-pointer">
                      No - Oppose the measure
                    </Label>
                  </div>
                </RadioGroup>
              </div>
            </div>

            {/* Submit Vote */}
            <div className="mt-8 pt-8 border-t border-gray-200">
              <div className="flex justify-between items-center">
                <p className="text-sm text-gray-600">
                  Review your selections before submitting
                </p>
                <Button
                  onClick={onSubmitVote}
                  className="success-button"
                  disabled={Object.keys(voteSelections).length === 0}
                >
                  <Send className="w-4 h-4 mr-2" />
                  Submit Vote
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <VoteConfirmationModal
          isOpen={showConfirmation}
          onClose={() => setShowConfirmation(false)}
          onConfirm={onConfirmVote}
          ballot={currentBallot}
          selections={voteSelections}
        />
      </div>
    );
  }

  return null;
}
