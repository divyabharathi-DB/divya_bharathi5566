import { Link, useLocation } from "wouter";
import { Vote, Settings, BarChart3, Brain } from "lucide-react";

export default function Navigation() {
  const [location] = useLocation();

  const navItems = [
    { path: "/", label: "Voter Portal", icon: Vote },
    { path: "/admin", label: "AI Admin", icon: Brain },
    { path: "/results", label: "Results", icon: BarChart3 },
  ];

  return (
    <nav className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2">
              <Brain className="text-blue-600 w-8 h-8" />
              <Vote className="text-blue-600 w-6 h-6" />
            </div>
            <div>
              <span className="text-xl font-bold professional-text">SecureVote AI</span>
              <div className="text-xs text-blue-600 font-medium">Intelligent Election Security</div>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            {navItems.map(({ path, label, icon: Icon }) => (
              <Link
                key={path}
                href={path}
                className={`nav-link flex items-center space-x-2 ${
                  location === path ? 'active' : ''
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{label}</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
}
