import { useQuery } from "@tanstack/react-query";
import { Brain, Shield, TrendingUp, AlertTriangle, CheckCircle, XCircle, Activity } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

interface AIInsights {
  turnoutPrediction: number;
  votingTrends: Array<{
    hour: number;
    activity: number;
    trend: 'high' | 'medium' | 'low';
  }>;
  anomalies: string[];
  recommendations: string[];
}

interface IntegrityStatus {
  integrityScore: number;
  status: 'SECURE' | 'CAUTION' | 'ALERT';
  issues: string[];
  actions: string[];
}

export default function AIDashboard() {
  // Get AI insights
  const { data: insights } = useQuery<AIInsights>({
    queryKey: ['/api/ai/insights'],
    refetchInterval: 30000,
  });

  // Get integrity monitoring
  const { data: integrity } = useQuery<IntegrityStatus>({
    queryKey: ['/api/ai/integrity'],
    refetchInterval: 15000,
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'SECURE': return 'text-green-600 bg-green-50 border-green-200';
      case 'CAUTION': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'ALERT': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'SECURE': return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'CAUTION': return <AlertTriangle className="w-5 h-5 text-yellow-600" />;
      case 'ALERT': return <XCircle className="w-5 h-5 text-red-600" />;
      default: return <Activity className="w-5 h-5 text-gray-600" />;
    }
  };

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'high': return 'bg-blue-600';
      case 'medium': return 'bg-blue-400';
      case 'low': return 'bg-blue-200';
      default: return 'bg-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* AI Control Header */}
      <div className="flex items-center space-x-3 mb-6">
        <Brain className="text-blue-600 w-8 h-8" />
        <div>
          <h2 className="text-2xl font-bold professional-text">AI Election Control</h2>
          <p className="text-gray-600">Intelligent monitoring and fraud detection</p>
        </div>
      </div>

      {/* Security Status */}
      {integrity && (
        <Card className="voting-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="w-5 h-5 text-blue-600" />
              <span>Election Integrity Status</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className={`flex items-center space-x-3 p-4 rounded-lg border ${getStatusColor(integrity.status)}`}>
                  {getStatusIcon(integrity.status)}
                  <div>
                    <div className="font-semibold">{integrity.status}</div>
                    <div className="text-sm">Security Status</div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium">Integrity Score</span>
                    <span className="text-sm text-gray-600">{Math.round(integrity.integrityScore * 100)}%</span>
                  </div>
                  <Progress value={integrity.integrityScore * 100} className="h-3" />
                </div>
              </div>
              
              <div className="space-y-4">
                {integrity.issues.length > 0 && (
                  <div>
                    <h4 className="font-medium text-red-600 mb-2">Security Issues</h4>
                    <ul className="space-y-1">
                      {integrity.issues.map((issue, index) => (
                        <li key={index} className="text-sm text-red-600 flex items-center space-x-2">
                          <AlertTriangle className="w-3 h-3" />
                          <span>{issue}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                
                {integrity.actions.length > 0 && (
                  <div>
                    <h4 className="font-medium professional-text mb-2">Recommended Actions</h4>
                    <ul className="space-y-1">
                      {integrity.actions.map((action, index) => (
                        <li key={index} className="text-sm text-gray-600 flex items-center space-x-2">
                          <CheckCircle className="w-3 h-3 text-blue-600" />
                          <span>{action}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* AI Insights */}
      {insights && (
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Turnout Prediction */}
          <Card className="voting-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-green-600" />
                <span>AI Turnout Prediction</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-4">
                <div className="text-4xl font-bold text-green-600 mb-2">
                  {insights.turnoutPrediction.toFixed(1)}%
                </div>
                <div className="text-gray-600">Predicted Final Turnout</div>
              </div>
              
              <div className="space-y-3">
                {insights.recommendations.map((rec, index) => (
                  <div key={index} className="flex items-center space-x-2 text-sm">
                    <Brain className="w-4 h-4 text-blue-600" />
                    <span>{rec}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Voting Activity Trends */}
          <Card className="voting-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Activity className="w-5 h-5 text-blue-600" />
                <span>Real-time Activity Analysis</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm font-medium">
                  <span>Hour</span>
                  <span>Activity Level</span>
                </div>
                
                {insights.votingTrends.slice(-8).map((trend) => (
                  <div key={trend.hour} className="flex items-center justify-between">
                    <span className="text-sm">{trend.hour}:00</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${getTrendColor(trend.trend)}`}
                          style={{ width: `${Math.min((trend.activity / 20) * 100, 100)}%` }}
                        ></div>
                      </div>
                      <Badge variant={trend.trend === 'high' ? 'default' : 'secondary'}>
                        {trend.trend}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Anomaly Detection */}
      {insights && insights.anomalies.length > 0 && (
        <Card className="voting-card border-red-200">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-red-600">
              <AlertTriangle className="w-5 h-5" />
              <span>AI Anomaly Detection</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {insights.anomalies.map((anomaly, index) => (
                <div key={index} className="flex items-center space-x-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                  <XCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
                  <div>
                    <div className="font-medium text-red-800">{anomaly}</div>
                    <div className="text-sm text-red-600">Detected by AI security monitoring</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* AI Features Overview */}
      <Card className="voting-card">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Brain className="w-5 h-5 text-blue-600" />
            <span>AI Security Features</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <Shield className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <div className="font-medium">Biometric AI</div>
              <div className="text-sm text-gray-600">Facial recognition verification</div>
            </div>
            
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <AlertTriangle className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <div className="font-medium">Fraud Detection</div>
              <div className="text-sm text-gray-600">Real-time pattern analysis</div>
            </div>
            
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <TrendingUp className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <div className="font-medium">Predictive Analytics</div>
              <div className="text-sm text-gray-600">Turnout and trend prediction</div>
            </div>
            
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <Activity className="w-8 h-8 text-orange-600 mx-auto mb-2" />
              <div className="font-medium">Live Monitoring</div>
              <div className="text-sm text-gray-600">Continuous integrity checks</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}