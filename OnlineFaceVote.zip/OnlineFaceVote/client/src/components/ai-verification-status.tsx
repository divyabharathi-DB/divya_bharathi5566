import { Brain, Shield, CheckCircle, AlertTriangle, Activity } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

interface AIVerificationProps {
  aiAnalysis?: string;
  confidence?: number;
  fraudRisk?: 'LOW' | 'MEDIUM' | 'HIGH';
  securityScore?: number;
  isVisible: boolean;
}

export default function AIVerificationStatus({
  aiAnalysis,
  confidence,
  fraudRisk,
  securityScore,
  isVisible
}: AIVerificationProps) {
  if (!isVisible) return null;

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'LOW': return 'bg-green-100 text-green-800 border-green-200';
      case 'MEDIUM': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'HIGH': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getConfidenceColor = (conf: number) => {
    if (conf >= 0.9) return 'text-green-600';
    if (conf >= 0.8) return 'text-blue-600';
    if (conf >= 0.7) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <Card className="voting-card border-blue-200 bg-blue-50">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2 text-blue-800">
          <Brain className="w-5 h-5" />
          <span>AI Security Verification</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Confidence Score */}
        {confidence && (
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-blue-800">Identity Confidence</span>
              <span className={`text-sm font-bold ${getConfidenceColor(confidence)}`}>
                {Math.round(confidence * 100)}%
              </span>
            </div>
            <Progress value={confidence * 100} className="h-2" />
          </div>
        )}

        {/* Security Score */}
        {securityScore && (
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-blue-800">Security Score</span>
              <span className="text-sm font-bold text-green-600">{securityScore}/100</span>
            </div>
            <Progress value={securityScore} className="h-2" />
          </div>
        )}

        {/* Fraud Risk */}
        {fraudRisk && (
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-blue-800">Fraud Risk Assessment</span>
            <Badge className={`${getRiskColor(fraudRisk)} border`}>
              {fraudRisk} RISK
            </Badge>
          </div>
        )}

        {/* AI Analysis */}
        {aiAnalysis && (
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Activity className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-800">AI Analysis</span>
            </div>
            <p className="text-sm text-blue-700 bg-white p-3 rounded border border-blue-200">
              {aiAnalysis}
            </p>
          </div>
        )}

        {/* Security Features */}
        <div className="grid grid-cols-2 gap-3 pt-3 border-t border-blue-200">
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-green-600" />
            <span className="text-xs text-blue-700">Biometric Verified</span>
          </div>
          <div className="flex items-center space-x-2">
            <Shield className="w-4 h-4 text-blue-600" />
            <span className="text-xs text-blue-700">Fraud Protected</span>
          </div>
          <div className="flex items-center space-x-2">
            <Brain className="w-4 h-4 text-purple-600" />
            <span className="text-xs text-blue-700">AI Monitored</span>
          </div>
          <div className="flex items-center space-x-2">
            <Activity className="w-4 h-4 text-orange-600" />
            <span className="text-xs text-blue-700">Real-time Analysis</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}