import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Check, Lock } from "lucide-react";
import type { Ballot, VoteSelections } from "@/lib/types";

interface VoteConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  ballot: Ballot | null;
  selections: VoteSelections;
}

export default function VoteConfirmationModal({
  isOpen,
  onClose,
  onConfirm,
  ballot,
  selections
}: VoteConfirmationModalProps) {
  if (!ballot) return null;

  const getSelectionDisplay = (questionId: string, value: string) => {
    if (questionId === 'president') {
      const candidate = ballot.candidates.find(c => c.id === value);
      return candidate ? `${candidate.name} (${candidate.party})` : value;
    }
    return value === 'yes' ? 'Yes - Support the measure' : 'No - Oppose the measure';
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <div className="text-center mb-4">
            <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="text-white w-8 h-8" />
            </div>
            <DialogTitle className="text-2xl font-semibold professional-text mb-2">
              Confirm Your Vote
            </DialogTitle>
            <p className="text-gray-600">Please review your selections before final submission</p>
          </div>
        </DialogHeader>
        
        <div className="space-y-4 mb-6">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-medium professional-text mb-2">{ballot.title}</h3>
            {selections.president ? (
              <p className="text-sm text-gray-600">
                {getSelectionDisplay('president', selections.president)}
              </p>
            ) : (
              <p className="text-sm text-gray-500">No selection made</p>
            )}
          </div>
          
          {selections.proposition12 !== undefined && (
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-medium professional-text mb-2">Proposition 12</h3>
              <p className="text-sm text-gray-600">
                {getSelectionDisplay('proposition12', selections.proposition12)}
              </p>
            </div>
          )}
        </div>
        
        <div className="flex space-x-4">
          <Button
            onClick={onClose}
            variant="outline"
            className="flex-1"
          >
            Review Changes
          </Button>
          <Button
            onClick={onConfirm}
            className="flex-1 success-button"
          >
            <Lock className="w-4 h-4 mr-2" />
            Cast Vote
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
