import { useState, useRef, useCallback } from "react";
import { Camera, Check, Video } from "lucide-react";
import { Button } from "@/components/ui/button";

interface FaceCaptureProps {
  onCapture: (faceData: string) => void;
  onError?: (error: string) => void;
}

export default function FaceCapture({ onCapture, onError }: FaceCaptureProps) {
  const [isActive, setIsActive] = useState(false);
  const [isCaptured, setIsCaptured] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const startCapture = useCallback(async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480 }
      });
      
      setStream(mediaStream);
      setIsActive(true);
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (error) {
      console.error("Error accessing camera:", error);
      onError?.("Failed to access camera. Please ensure you have granted camera permissions.");
    }
  }, [onError]);

  const captureImage = useCallback(() => {
    if (!videoRef.current) return;

    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    
    if (context) {
      context.drawImage(videoRef.current, 0, 0);
      const imageData = canvas.toDataURL('image/jpeg', 0.8);
      
      // Stop the stream
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      
      setIsActive(false);
      setIsCaptured(true);
      onCapture(imageData);
    }
  }, [stream, onCapture]);

  if (isCaptured) {
    return (
      <div className="text-center">
        <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-4">
          <Check className="text-green-600 w-12 h-12 mx-auto mb-2" />
          <p className="text-green-600 font-medium">Face verification successful!</p>
          <p className="text-sm text-gray-600 mt-1">Your biometric profile has been securely stored</p>
        </div>
      </div>
    );
  }

  return (
    <div className="text-center">
      <div className="relative bg-gray-100 rounded-xl p-8 mb-6 border-2 border-dashed border-gray-300">
        {isActive ? (
          <div className="relative">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              className="w-full h-64 bg-gray-800 rounded-lg object-cover"
            />
            <div className="absolute inset-4 border-2 border-blue-600 rounded-lg pointer-events-none"></div>
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 text-white text-sm bg-black bg-opacity-50 px-3 py-1 rounded">
              Position your face in the frame
            </div>
          </div>
        ) : (
          <div className="text-center">
            <Camera className="text-blue-600 w-16 h-16 mx-auto mb-4" />
            <p className="professional-text text-lg mb-4">Set up face recognition for secure voting</p>
            <p className="text-gray-600">Your biometric data will be encrypted and used only for identity verification</p>
          </div>
        )}
      </div>
      
      <div className="space-y-4">
        {!isActive ? (
          <Button onClick={startCapture} className="w-full trust-button">
            <Video className="w-4 h-4 mr-2" />
            Start Face Capture
          </Button>
        ) : (
          <Button onClick={captureImage} className="w-full success-button">
            <Camera className="w-4 h-4 mr-2" />
            Capture Image
          </Button>
        )}
      </div>
    </div>
  );
}
