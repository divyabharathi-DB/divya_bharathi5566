import type { Voter, Ballot, Candidate } from "@shared/schema";

export interface VoterRegistration {
  firstName: string;
  lastName: string;
  email: string;
  voterId: string;
  address: string;
}

export interface VoteSelections {
  [questionId: string]: string;
}

export interface VotingStats {
  totalVotes: number;
  activeVoters: number;
  turnoutRate: number;
  registeredVoters: number;
}

export interface BallotResults {
  ballot: Ballot;
  totalVotes: number;
  results: Record<string, number>;
}

export interface SecurityLogEntry {
  id: number;
  eventType: string;
  userId?: string;
  details: string;
  ipAddress?: string;
  success: boolean;
  timestamp: Date;
}

export { type Voter, type Ballot, type Candidate };
