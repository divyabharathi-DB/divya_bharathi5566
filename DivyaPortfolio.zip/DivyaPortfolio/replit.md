# Overview

This is a professional portfolio website built for Divya Bharathi B, a Computer Science graduate and MCA student. The application showcases her education, skills, projects, certifications, professional experience, and provides a contact form for potential opportunities. The portfolio is designed to highlight her expertise in AI/ML, web development, and data science.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built with React and TypeScript using a component-based architecture. The application uses Vite as the build tool and development server, providing fast hot module replacement and optimized builds. The UI is implemented with shadcn/ui components built on top of Radix UI primitives, ensuring accessibility and consistency. Styling is handled through Tailwind CSS with a custom design system including CSS variables for theming.

The application follows a single-page application (SPA) pattern with client-side routing using Wouter. State management is handled through React Query for server state and React's built-in state management for local component state. The component structure is organized into sections (Hero, About, Skills, Projects, Certifications, Experience, Contact) with reusable UI components in a dedicated components/ui directory.

## Backend Architecture
The backend is a Node.js Express server written in TypeScript using ES modules. The server follows a minimal API design with a single contact form endpoint. The application uses a development/production split where Vite middleware is integrated in development mode for seamless full-stack development, while in production, static files are served directly.

The server implements request logging middleware that captures API calls with timing information and response data. Error handling is centralized through Express middleware that standardizes error responses across the application.

## Data Storage
The application uses an in-memory storage implementation for basic user data with interfaces designed to support future database integration. Drizzle ORM is configured for PostgreSQL with migration support, indicating the architecture is prepared for database-backed features. The schema defines a basic user table with UUID primary keys.

## UI Framework and Design System
The design system is built on shadcn/ui with Tailwind CSS, providing a comprehensive component library including forms, dialogs, toasts, navigation menus, and data display components. The design system supports both light and dark themes through CSS custom properties and includes responsive design patterns for mobile and desktop experiences.

## Build and Development Tooling
The project uses a modern development stack with TypeScript for type safety, ESBuild for production builds, and comprehensive path aliasing for clean imports. The build process creates separate outputs for client (Vite build) and server (ESBuild bundle), enabling deployment to various hosting platforms.

# External Dependencies

## UI and Styling
- **Radix UI**: Comprehensive set of low-level UI primitives for accessibility and customization
- **Tailwind CSS**: Utility-first CSS framework for rapid UI development
- **shadcn/ui**: Pre-built component library combining Radix UI with Tailwind CSS
- **Lucide Icons**: Icon library for consistent visual elements
- **FontAwesome**: Additional icon set for specialized icons

## State Management and Data Fetching
- **TanStack React Query**: Server state management with caching, synchronization, and background updates
- **React Hook Form**: Form state management with validation
- **Zod**: Schema validation for form data and API responses

## Database and ORM
- **Drizzle ORM**: Type-safe SQL ORM with PostgreSQL support
- **Drizzle Kit**: Database migration and schema management tools
- **@neondatabase/serverless**: Serverless PostgreSQL driver for Neon database

## Development and Build Tools
- **Vite**: Fast build tool and development server with React plugin support
- **TypeScript**: Static type checking for enhanced developer experience
- **ESBuild**: Fast JavaScript bundler for production builds
- **Replit Plugins**: Development environment integration for error overlays and debugging

## Runtime and Server
- **Express.js**: Web application framework for Node.js
- **Connect-pg-simple**: PostgreSQL session store for Express sessions
- **Date-fns**: Date manipulation and formatting library
- **Wouter**: Lightweight client-side routing library