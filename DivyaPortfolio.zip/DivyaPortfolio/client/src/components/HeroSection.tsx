import { useState } from "react";
import profileImage from "@assets/Web_Photo_Editor_1758775969499.jpg";

export default function HeroSection() {
  const [isDownloading, setIsDownloading] = useState(false);

  const downloadResume = async () => {
    setIsDownloading(true);
    try {
      const response = await fetch('/api/download-resume', {
        method: 'GET',
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'Divya_Bharathi_Resume.pdf';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      } else {
        console.error('Failed to download resume');
      }
    } catch (error) {
      console.error('Error downloading resume:', error);
    } finally {
      setIsDownloading(false);
    }
  };

  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      const headerOffset = 100;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="home" className="min-h-screen hero-gradient flex items-center justify-center pt-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <div className="animate-fade-in-up">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary-foreground mb-6">
                Hi, I'm <span className="text-accent-foreground">Divya Bharathi B</span>
              </h1>
              <p className="text-xl md:text-2xl text-primary-foreground/90 mb-6 font-medium">
                Computer Science Graduate | MCA Student | Aspiring Developer & AI/ML Enthusiast
              </p>
              <p className="text-lg text-primary-foreground/80 mb-8 leading-relaxed">
                Motivated and detail-oriented Computer Science graduate currently pursuing MCA at SRM Institute of Science and Technology. Skilled in Python, Web Development, AI/ML concepts, and Project Management, with hands-on experience through academic projects, certifications, and internships.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <button 
                  onClick={downloadResume}
                  disabled={isDownloading}
                  className="px-8 py-3 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold rounded-lg transition-all duration-300 hover:scale-105 shadow-lg disabled:opacity-50"
                  data-testid="button-download-resume"
                >
                  <i className="fas fa-download mr-2"></i>
                  {isDownloading ? 'Downloading...' : 'Download Resume'}
                </button>
                <button 
                  onClick={scrollToContact}
                  className="px-8 py-3 border-2 border-primary-foreground/30 hover:bg-primary-foreground/10 text-primary-foreground font-semibold rounded-lg transition-all duration-300 hover:scale-105"
                  data-testid="button-contact-me"
                >
                  <i className="fas fa-envelope mr-2"></i>
                  Contact Me
                </button>
              </div>
            </div>
          </div>
          <div className="flex justify-center lg:justify-end">
            <div className="relative">
              <div className="w-80 h-80 md:w-96 md:h-96 rounded-full overflow-hidden shadow-2xl border-8 border-primary-foreground/20">
                <img 
                  src={profileImage} 
                  alt="Divya Bharathi B - Professional Photo" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-transparent to-white/20"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
