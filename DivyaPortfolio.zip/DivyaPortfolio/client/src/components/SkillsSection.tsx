export default function SkillsSection() {
  const technicalSkills = [
    "Python", "HTML", "CSS", "JavaScript", "Node.js", "Git", 
    "Machine Learning", "Natural Language Processing", "Data Science", "API Integration"
  ];

  const softSkillsData = [
    { name: "Project Management", level: 80 },
    { name: "Communication", level: 85 },
    { name: "Leadership", level: 80 },
    { name: "Time Management", level: 85 },
    { name: "Critical Thinking", level: 80 },
    { name: "Teamwork", level: 85 }
  ];

  return (
    <section id="skills" className="py-20 px-4 bg-muted/50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">Skills & Expertise</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A comprehensive skill set spanning technical programming languages, development frameworks, and essential soft skills for professional success.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-12">
          {/* Technical Skills */}
          <div className="bg-card rounded-xl p-8 shadow-lg border border-border">
            <h3 className="text-2xl font-bold mb-6 text-foreground flex items-center">
              <i className="fas fa-code text-primary mr-3"></i>Technical Skills
            </h3>
            <div className="flex flex-wrap gap-3">
              {technicalSkills.map((skill) => (
                <span 
                  key={skill}
                  className="skill-tag bg-secondary text-secondary-foreground px-4 py-2 rounded-full font-medium cursor-pointer"
                  data-testid={`skill-${skill.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>

          {/* Soft Skills */}
          <div className="bg-card rounded-xl p-8 shadow-lg border border-border">
            <h3 className="text-2xl font-bold mb-6 text-foreground flex items-center">
              <i className="fas fa-users text-accent mr-3"></i>Soft Skills
            </h3>
            <div className="space-y-4">
              {softSkillsData.map((skill) => (
                <div key={skill.name} className="flex items-center justify-between">
                  <span className="text-foreground font-medium">{skill.name}</span>
                  <div className="w-32 bg-secondary rounded-full h-2">
                    <div 
                      className="bg-primary h-2 rounded-full transition-all duration-1000"
                      style={{ width: `${skill.level}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
