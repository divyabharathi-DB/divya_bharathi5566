export default function ProjectsSection() {
  const projects = [
    {
      title: "Medical Chatbot",
      description: "NLP-based chatbot designed to handle patient queries, providing accurate medical information and preliminary diagnosis assistance using natural language processing techniques.",
      technologies: ["Python", "NLP", "Machine Learning"],
      image: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400"
    },
    {
      title: "Portfolio Optimization & Investment Management",
      description: "Data-driven investment model using Python to optimize portfolio allocation, risk assessment, and return prediction for better investment decisions.",
      technologies: ["Python", "Data Science", "Finance"],
      image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400"
    },
    {
      title: "Credit Card Fraud Detection",
      description: "Machine learning model designed to detect fraudulent credit card transactions using advanced algorithms and pattern recognition techniques.",
      technologies: ["Machine Learning", "Python", "Security"],
      image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400"
    }
  ];

  return (
    <section id="projects" className="py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">Featured Projects</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Innovative solutions leveraging AI, machine learning, and web technologies to solve real-world problems.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div 
              key={index}
              className="card-hover bg-card rounded-xl overflow-hidden shadow-lg border border-border"
              data-testid={`project-${project.title.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <img 
                src={project.image} 
                alt={`${project.title} concept image`}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold text-foreground mb-3">{project.title}</h3>
                <p className="text-muted-foreground mb-4">{project.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.technologies.map((tech) => (
                    <span 
                      key={tech}
                      className="bg-primary/10 text-primary px-2 py-1 rounded text-sm"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                <button className="text-accent hover:underline font-medium">
                  View Details →
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
