export default function AboutSection() {
  return (
    <section id="about" className="py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">About Me</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A passionate technology enthusiast with a strong foundation in computer science and a drive to innovate in the fields of AI and machine learning.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-12">
          {/* Education Timeline */}
          <div className="bg-card rounded-xl p-8 shadow-lg border border-border">
            <h3 className="text-2xl font-bold mb-6 text-foreground">Education</h3>
            <div className="relative pl-8">
              <div className="timeline-item relative mb-8">
                <div className="ml-6">
                  <h4 className="font-semibold text-foreground">Master of Computer Applications (MCA)</h4>
                  <p className="text-muted-foreground text-sm">SRM Institute of Science and Technology, Vadapalani</p>
                  <p className="text-muted-foreground text-sm">Currently Pursuing</p>
                </div>
              </div>
              <div className="timeline-item relative mb-8">
                <div className="ml-6">
                  <h4 className="font-semibold text-foreground">B.Sc. Computer Science</h4>
                  <p className="text-muted-foreground text-sm">Anna Adarsh College for Women</p>
                  <p className="text-muted-foreground text-sm">CGPA: 6.8 | Percentage: 68.9% | 2024</p>
                </div>
              </div>
              <div className="timeline-item relative mb-8">
                <div className="ml-6">
                  <h4 className="font-semibold text-foreground">HSC +2</h4>
                  <p className="text-muted-foreground text-sm">Balalok Matric Hr. Sec. School</p>
                  <p className="text-muted-foreground text-sm">Percentage: 76.13% | 2021</p>
                </div>
              </div>
              <div className="timeline-item relative">
                <div className="ml-6">
                  <h4 className="font-semibold text-foreground">SSLC 10th</h4>
                  <p className="text-muted-foreground text-sm">Balalok Matric Hr. Sec. School</p>
                  <p className="text-muted-foreground text-sm">Percentage: 66.8%</p>
                </div>
              </div>
            </div>
          </div>

          {/* Personal Information */}
          <div className="space-y-8">
            <div className="bg-card rounded-xl p-8 shadow-lg border border-border">
              <h3 className="text-2xl font-bold mb-6 text-foreground">Languages</h3>
              <div className="flex flex-wrap gap-3">
                <span className="bg-primary/10 text-primary px-4 py-2 rounded-full font-medium">English</span>
                <span className="bg-primary/10 text-primary px-4 py-2 rounded-full font-medium">Tamil</span>
              </div>
            </div>
            
            <div className="bg-card rounded-xl p-8 shadow-lg border border-border">
              <h3 className="text-2xl font-bold mb-6 text-foreground">Personal Qualities</h3>
              <ul className="space-y-3">
                <li className="flex items-center text-muted-foreground">
                  <i className="fas fa-check-circle text-accent mr-3"></i>
                  Detail-oriented and analytical mindset
                </li>
                <li className="flex items-center text-muted-foreground">
                  <i className="fas fa-check-circle text-accent mr-3"></i>
                  Strong problem-solving abilities
                </li>
                <li className="flex items-center text-muted-foreground">
                  <i className="fas fa-check-circle text-accent mr-3"></i>
                  Excellent communication skills
                </li>
                <li className="flex items-center text-muted-foreground">
                  <i className="fas fa-check-circle text-accent mr-3"></i>
                  Natural leadership qualities
                </li>
                <li className="flex items-center text-muted-foreground">
                  <i className="fas fa-check-circle text-accent mr-3"></i>
                  Adaptable and quick learner
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
