export default function ExperienceSection() {
  const responsibilities = [
    "Designed and developed responsive web pages using HTML, CSS, and JavaScript, ensuring cross-browser compatibility and mobile-first design principles",
    "Successfully integrated frontend applications with backend services through RESTful APIs, collaborating closely with backend developers",
    "Utilized Git for version control, maintaining clean code history and facilitating collaborative development workflows",
    "Participated in daily stand-ups and sprint planning, contributing to agile development processes"
  ];

  const technologies = [
    "HTML5", "CSS3", "JavaScript", "Git", "API Integration", "Responsive Design"
  ];

  return (
    <section id="experience" className="py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">Professional Experience</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Hands-on experience in web development and modern technologies through internships and practical projects.
          </p>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <div className="bg-card rounded-xl p-8 shadow-lg border border-border" data-testid="experience-wiztech">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
              <div>
                <h3 className="text-2xl font-bold text-foreground mb-2">Web Developer (Frontend) - Internship</h3>
                <p className="text-lg text-primary font-semibold">Wiztech Automation Solutions</p>
                <p className="text-muted-foreground">May 2025 - June 2025</p>
              </div>
              <div className="mt-4 md:mt-0">
                <span className="bg-accent/10 text-accent px-3 py-1 rounded-full text-sm font-medium">Internship</span>
              </div>
            </div>
            
            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-foreground">Key Responsibilities & Achievements:</h4>
              <ul className="space-y-3">
                {responsibilities.map((responsibility, index) => (
                  <li key={index} className="flex items-start text-muted-foreground">
                    <i className="fas fa-check-circle text-accent mr-3 mt-1"></i>
                    <span>{responsibility}</span>
                  </li>
                ))}
              </ul>
              
              <div className="mt-6">
                <h4 className="text-lg font-semibold text-foreground mb-3">Technologies Used:</h4>
                <div className="flex flex-wrap gap-3">
                  {technologies.map((tech) => (
                    <span 
                      key={tech}
                      className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
