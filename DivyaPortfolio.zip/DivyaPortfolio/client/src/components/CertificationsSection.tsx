export default function CertificationsSection() {
  const infosysCertifications = [
    "Introduction to Artificial Intelligence",
    "Introduction to Natural Language Processing"
  ];

  const harvardCertifications = [
    "Data Science: Machine Learning",
    "Data Science: Productivity Tools"
  ];

  const achievements = [
    {
      icon: "fas fa-robot",
      title: "AI/ML Projects",
      description: "Built academic projects with real-world applications in AI and machine learning"
    },
    {
      icon: "fas fa-trophy",
      title: "Industry Recognition",
      description: "Earned certifications from leading institutions like Infosys and Harvard"
    },
    {
      icon: "fas fa-users",
      title: "Leadership Skills",
      description: "Demonstrated strong teamwork and leadership abilities throughout projects"
    }
  ];

  return (
    <section id="certifications" className="py-20 px-4 bg-muted/50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">Certifications & Achievements</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Industry-recognized certifications from prestigious institutions demonstrating expertise in AI, machine learning, and data science.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          {/* Infosys Certifications */}
          <div className="bg-card rounded-xl p-8 shadow-lg border border-border">
            <div className="flex items-center mb-6">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mr-4">
                <i className="fas fa-certificate text-primary text-2xl"></i>
              </div>
              <div>
                <h3 className="text-xl font-bold text-foreground">Infosys Springboard</h3>
                <p className="text-muted-foreground">Industry Leader in Technology Training</p>
              </div>
            </div>
            <ul className="space-y-3">
              {infosysCertifications.map((cert) => (
                <li key={cert} className="flex items-center text-muted-foreground">
                  <i className="fas fa-award text-accent mr-3"></i>
                  {cert}
                </li>
              ))}
            </ul>
          </div>

          {/* Harvard Certifications */}
          <div className="bg-card rounded-xl p-8 shadow-lg border border-border">
            <div className="flex items-center mb-6">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mr-4">
                <i className="fas fa-graduation-cap text-primary text-2xl"></i>
              </div>
              <div>
                <h3 className="text-xl font-bold text-foreground">Harvard University</h3>
                <p className="text-muted-foreground">Prestigious Academic Institution</p>
              </div>
            </div>
            <ul className="space-y-3">
              {harvardCertifications.map((cert) => (
                <li key={cert} className="flex items-center text-muted-foreground">
                  <i className="fas fa-award text-accent mr-3"></i>
                  {cert}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Achievements */}
        <div className="mt-12">
          <h3 className="text-2xl font-bold text-foreground mb-8 text-center">Key Achievements</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {achievements.map((achievement, index) => (
              <div 
                key={index}
                className="bg-card rounded-xl p-6 shadow-lg border border-border text-center"
                data-testid={`achievement-${achievement.title.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <i className={`${achievement.icon} text-primary text-3xl mb-4`}></i>
                <h4 className="font-bold text-foreground mb-2">{achievement.title}</h4>
                <p className="text-muted-foreground text-sm">{achievement.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
