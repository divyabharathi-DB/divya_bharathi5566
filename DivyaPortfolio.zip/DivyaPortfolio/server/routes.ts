import type { Express } from "express";
import { createServer, type Server } from "http";
import path from "path";
import fs from "fs";

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form submission endpoint
  app.post("/api/contact", (req, res) => {
    try {
      const { name, email, subject, message } = req.body;

      // Validate required fields
      if (!name || !email || !subject || !message) {
        return res.status(400).json({ 
          error: "All fields are required: name, email, subject, message" 
        });
      }

      // Email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({ 
          error: "Please provide a valid email address" 
        });
      }

      // In a real application, you would:
      // 1. Send email using a service like SendGrid, AWS SES, etc.
      // 2. Save to database
      // 3. Send notifications
      
      console.log("Contact form submission:", {
        name,
        email,
        subject,
        message,
        timestamp: new Date().toISOString()
      });

      res.json({ 
        success: true, 
        message: "Your message has been received. Thank you for contacting me!" 
      });
    } catch (error) {
      console.error("Error processing contact form:", error);
      res.status(500).json({ 
        error: "Failed to process your message. Please try again later." 
      });
    }
  });

  // Resume download endpoint
  app.get("/api/download-resume", (req, res) => {
    try {
      // In production, this would serve the actual PDF file
      // For now, we'll create a simple PDF-like response
      const resumePath = path.join(process.cwd(), "attached_assets", "Divya_Bharathi_resume_1758776002194.pdf");
      
      // Check if the resume file exists
      if (fs.existsSync(resumePath)) {
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', 'attachment; filename="Divya_Bharathi_Resume.pdf"');
        
        const fileStream = fs.createReadStream(resumePath);
        fileStream.pipe(res);
      } else {
        // If file doesn't exist, create a simple text response indicating where the PDF would be
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', 'attachment; filename="Divya_Bharathi_Resume.pdf"');
        
        // Create a simple PDF-like buffer (in production, use a proper PDF library)
        const pdfContent = Buffer.from(`
          %PDF-1.4
          1 0 obj
          <<
          /Type /Catalog
          /Pages 2 0 R
          >>
          endobj
          
          2 0 obj
          <<
          /Type /Pages
          /Kids [3 0 R]
          /Count 1
          >>
          endobj
          
          3 0 obj
          <<
          /Type /Page
          /Parent 2 0 R
          /MediaBox [0 0 612 792]
          /Contents 4 0 R
          >>
          endobj
          
          4 0 obj
          <<
          /Length 44
          >>
          stream
          BT
          /F1 12 Tf
          72 720 Td
          (Divya Bharathi B - Resume) Tj
          ET
          endstream
          endobj
          
          xref
          0 5
          0000000000 65535 f 
          0000000009 00000 n 
          0000000058 00000 n 
          0000000115 00000 n 
          0000000212 00000 n 
          trailer
          <<
          /Size 5
          /Root 1 0 R
          >>
          startxref
          306
          %%EOF
        `);
        
        res.send(pdfContent);
      }
    } catch (error) {
      console.error("Error serving resume:", error);
      res.status(500).json({ 
        error: "Failed to download resume. Please try again later." 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
