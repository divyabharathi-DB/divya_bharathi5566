import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./replit_integrations/auth";
import { registerAuthRoutes } from "./replit_integrations/auth/routes";
import { api } from "@shared/routes";
import { z } from "zod";
import { isAuthenticated } from "./replit_integrations/auth/replitAuth";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Auth
  await setupAuth(app);
  registerAuthRoutes(app);

  // Help Requests
  app.get(api.helpRequests.list.path, isAuthenticated, async (req: any, res) => {
    try {
      const requests = await storage.getUserHelpRequests(req.user.claims.sub);
      res.json(requests);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.helpRequests.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.helpRequests.create.input.parse(req.body);
      const request = await storage.createHelpRequest(req.user.claims.sub, input);
      res.status(201).json(request);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      } else {
        console.error(err);
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  // Admin Help Request Status Update (For now, just authenticated users can do it for demo purposes, or add a check)
  app.patch(api.helpRequests.updateStatus.path, isAuthenticated, async (req, res) => {
     try {
       const id = parseInt(req.params.id);
       const input = api.helpRequests.updateStatus.input.parse(req.body);
       const updated = await storage.updateHelpRequestStatus(id, input.status, input.adminResponse);
       if (!updated) return res.status(404).json({ message: "Request not found" });
       res.json(updated);
     } catch (err) {
        if (err instanceof z.ZodError) {
          res.status(400).json({ message: err.errors[0].message });
        } else {
          res.status(500).json({ message: "Internal server error" });
        }
     }
  });

  // SOS Alerts
  app.post(api.sos.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.sos.create.input.parse(req.body);
      const alert = await storage.createSosAlert(req.user.claims.sub, input);
      res.status(201).json(alert);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get(api.sos.list.path, isAuthenticated, async (req, res) => {
    try {
      const alerts = await storage.getActiveSosAlerts();
      res.json(alerts);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch(api.sos.resolve.path, isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updated = await storage.resolveSosAlert(id);
      if (!updated) return res.status(404).json({ message: "Alert not found" });
      res.json(updated);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Resources (Publicly accessible)
  app.get(api.resources.list.path, async (req, res) => {
    try {
      const resources = await storage.getAllResources();
      res.json(resources);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.resources.create.path, isAuthenticated, async (req, res) => {
    try {
       const input = api.resources.create.input.parse(req.body);
       const resource = await storage.createResource(input);
       res.status(201).json(resource);
    } catch (err) {
        if (err instanceof z.ZodError) {
          res.status(400).json({ message: err.errors[0].message });
        } else {
          res.status(500).json({ message: "Internal server error" });
        }
    }
  });

  // Seeding
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existingResources = await storage.getAllResources();
  if (existingResources.length === 0) {
    await storage.createResource({
      title: "National Domestic Violence Hotline",
      category: "Helpline",
      content: "24/7 confidential support for victims of domestic violence.",
      contactNumber: "1-800-799-SAFE",
    });
    await storage.createResource({
      title: "Workplace Harassment Rights",
      category: "Legal",
      content: "Know your rights against workplace harassment. You are protected under Title VII.",
      contactNumber: null,
    });
    await storage.createResource({
      title: "Emergency Shelter Locator",
      category: "Safety",
      content: "Find safe shelters near you. Visit safewomenshelters.org",
      contactNumber: null,
    });
  }
}
