import { db } from "./db";
import {
  helpRequests,
  sosAlerts,
  resources,
  type HelpRequest,
  type InsertHelpRequest,
  type SosAlert,
  type InsertSosAlert,
  type Resource,
  type InsertResource,
  users,
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import { authStorage } from "./replit_integrations/auth/storage"; // Import auth storage

export interface IStorage {
  // Help Requests
  createHelpRequest(userId: string, request: InsertHelpRequest): Promise<HelpRequest>;
  getUserHelpRequests(userId: string): Promise<HelpRequest[]>;
  getAllHelpRequests(): Promise<HelpRequest[]>;
  updateHelpRequestStatus(id: number, status: "pending" | "in_progress" | "resolved", adminResponse?: string): Promise<HelpRequest | undefined>;
  getHelpRequest(id: number): Promise<HelpRequest | undefined>;

  // SOS Alerts
  createSosAlert(userId: string, alert: InsertSosAlert): Promise<SosAlert>;
  getActiveSosAlerts(): Promise<SosAlert[]>;
  getAllSosAlerts(): Promise<SosAlert[]>;
  resolveSosAlert(id: number): Promise<SosAlert | undefined>;

  // Resources
  getAllResources(): Promise<Resource[]>;
  createResource(resource: InsertResource): Promise<Resource>;
}

export class DatabaseStorage implements IStorage {
  // Help Requests
  async createHelpRequest(userId: string, request: InsertHelpRequest): Promise<HelpRequest> {
    const [newRequest] = await db
      .insert(helpRequests)
      .values({ ...request, userId })
      .returning();
    return newRequest;
  }

  async getUserHelpRequests(userId: string): Promise<HelpRequest[]> {
    return await db
      .select()
      .from(helpRequests)
      .where(eq(helpRequests.userId, userId))
      .orderBy(desc(helpRequests.createdAt));
  }

  async getAllHelpRequests(): Promise<HelpRequest[]> {
    return await db.select().from(helpRequests).orderBy(desc(helpRequests.createdAt));
  }

  async getHelpRequest(id: number): Promise<HelpRequest | undefined> {
    const [request] = await db.select().from(helpRequests).where(eq(helpRequests.id, id));
    return request;
  }

  async updateHelpRequestStatus(
    id: number,
    status: "pending" | "in_progress" | "resolved",
    adminResponse?: string
  ): Promise<HelpRequest | undefined> {
    const [updated] = await db
      .update(helpRequests)
      .set({ status, adminResponse })
      .where(eq(helpRequests.id, id))
      .returning();
    return updated;
  }

  // SOS Alerts
  async createSosAlert(userId: string, alert: InsertSosAlert): Promise<SosAlert> {
    const [newAlert] = await db
      .insert(sosAlerts)
      .values({ ...alert, userId })
      .returning();
    return newAlert;
  }

  async getActiveSosAlerts(): Promise<SosAlert[]> {
    return await db
      .select()
      .from(sosAlerts)
      .where(eq(sosAlerts.status, "active"))
      .orderBy(desc(sosAlerts.createdAt));
  }

  async getAllSosAlerts(): Promise<SosAlert[]> {
    return await db.select().from(sosAlerts).orderBy(desc(sosAlerts.createdAt));
  }

  async resolveSosAlert(id: number): Promise<SosAlert | undefined> {
    const [updated] = await db
      .update(sosAlerts)
      .set({ status: "resolved" })
      .where(eq(sosAlerts.id, id))
      .returning();
    return updated;
  }

  // Resources
  async getAllResources(): Promise<Resource[]> {
    return await db.select().from(resources).orderBy(desc(resources.createdAt));
  }

  async createResource(resource: InsertResource): Promise<Resource> {
    const [newResource] = await db.insert(resources).values(resource).returning();
    return newResource;
  }
}

export const storage = new DatabaseStorage();
