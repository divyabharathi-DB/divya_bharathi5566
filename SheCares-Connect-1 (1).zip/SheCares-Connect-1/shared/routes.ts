import { z } from "zod";
import { insertHelpRequestSchema, insertSosAlertSchema, insertResourceSchema, helpRequests, sosAlerts, resources, users } from "./schema";

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

export const api = {
  helpRequests: {
    list: {
      method: "GET" as const,
      path: "/api/help-requests",
      responses: {
        200: z.array(z.custom<typeof helpRequests.$inferSelect>()),
        401: errorSchemas.unauthorized,
      },
    },
    create: {
      method: "POST" as const,
      path: "/api/help-requests",
      input: insertHelpRequestSchema,
      responses: {
        201: z.custom<typeof helpRequests.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    updateStatus: {
      method: "PATCH" as const,
      path: "/api/help-requests/:id/status",
      input: z.object({
        status: z.enum(["pending", "in_progress", "resolved"]),
        adminResponse: z.string().optional(),
      }),
      responses: {
        200: z.custom<typeof helpRequests.$inferSelect>(),
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized,
      },
    },
  },
  sos: {
    create: {
      method: "POST" as const,
      path: "/api/sos",
      input: insertSosAlertSchema,
      responses: {
        201: z.custom<typeof sosAlerts.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    list: {
      method: "GET" as const,
      path: "/api/sos",
      responses: {
        200: z.array(z.custom<typeof sosAlerts.$inferSelect & { user?: typeof users.$inferSelect }>()), // Include user details for admin
        401: errorSchemas.unauthorized,
      },
    },
    resolve: {
      method: "PATCH" as const,
      path: "/api/sos/:id/resolve",
      responses: {
        200: z.custom<typeof sosAlerts.$inferSelect>(),
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized,
      },
    },
  },
  resources: {
    list: {
      method: "GET" as const,
      path: "/api/resources",
      responses: {
        200: z.array(z.custom<typeof resources.$inferSelect>()),
      },
    },
    create: {
      method: "POST" as const,
      path: "/api/resources",
      input: insertResourceSchema,
      responses: {
        201: z.custom<typeof resources.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
