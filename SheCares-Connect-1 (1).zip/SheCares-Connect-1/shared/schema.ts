import { pgTable, text, serial, integer, boolean, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { users } from "./models/auth";

// Export auth models
export * from "./models/auth";

// Enums
export const requestStatusEnum = pgEnum("request_status", ["pending", "in_progress", "resolved"]);
export const requestTypeEnum = pgEnum("request_type", [
  "harassment",
  "domestic_violence",
  "workplace_issue",
  "emergency",
  "other",
]);
export const sosStatusEnum = pgEnum("sos_status", ["active", "resolved"]);

// Help Requests
export const helpRequests = pgTable("help_requests", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(), // Foreign key to users.id (which is a varchar in auth schema)
  type: requestTypeEnum("type").notNull(),
  description: text("description").notNull(),
  status: requestStatusEnum("status").default("pending").notNull(),
  location: text("location"),
  adminResponse: text("admin_response"),
  createdAt: timestamp("created_at").defaultNow(),
});

// SOS Alerts
export const sosAlerts = pgTable("sos_alerts", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  location: text("location").notNull(),
  status: sosStatusEnum("status").default("active").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Resources
export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull(), // e.g., "Legal", "Safety", "Helpline"
  content: text("content").notNull(),
  contactNumber: text("contact_number"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Schemas
export const insertHelpRequestSchema = createInsertSchema(helpRequests).omit({
  id: true,
  userId: true,
  status: true,
  adminResponse: true,
  createdAt: true,
});

export const insertSosAlertSchema = createInsertSchema(sosAlerts).omit({
  id: true,
  userId: true,
  status: true,
  createdAt: true,
});

export const insertResourceSchema = createInsertSchema(resources).omit({
  id: true,
  createdAt: true,
});

// Types
export type HelpRequest = typeof helpRequests.$inferSelect;
export type InsertHelpRequest = z.infer<typeof insertHelpRequestSchema>;
export type SosAlert = typeof sosAlerts.$inferSelect;
export type InsertSosAlert = z.infer<typeof insertSosAlertSchema>;
export type Resource = typeof resources.$inferSelect;
export type InsertResource = z.infer<typeof insertResourceSchema>;
