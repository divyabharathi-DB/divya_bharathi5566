## Packages
framer-motion | Page transitions and animations
lucide-react | Beautiful icons for the UI
date-fns | Formatting dates

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["'DM Sans'", "sans-serif"],
  display: ["'Outfit'", "sans-serif"],
}
