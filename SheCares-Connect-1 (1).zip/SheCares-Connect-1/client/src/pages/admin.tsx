import { LayoutShell } from "@/components/layout-shell";
import { useHelpRequests, useUpdateHelpRequestStatus } from "@/hooks/use-help-requests";
import { useSosAlerts, useResolveSos } from "@/hooks/use-sos";
import { StatusBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  AlertTriangle, 
  MoreVertical, 
  CheckCircle2, 
  Clock, 
  MapPin,
  MessageSquare
} from "lucide-react";
import { format } from "date-fns";
import { Dialog, DialogContent, DialogTrigger, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";

export default function Admin() {
  const { data: requests } = useHelpRequests();
  const { data: alerts } = useSosAlerts();
  const { mutate: resolveSos } = useResolveSos();

  const activeAlerts = alerts?.filter(a => a.status === 'active') || [];

  return (
    <LayoutShell>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-gray-900">Admin Console</h1>
          <p className="text-gray-500 mt-1">Manage incidents and SOS alerts.</p>
        </div>

        {/* Active SOS Alerts - HIGH PRIORITY */}
        {activeAlerts.length > 0 && (
          <Card className="border-destructive/50 bg-red-50/50 animate-pulse">
            <CardHeader>
              <CardTitle className="text-destructive flex items-center gap-2">
                <AlertTriangle className="w-5 h-5" />
                Active SOS Alerts ({activeAlerts.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {activeAlerts.map(alert => (
                  <div key={alert.id} className="bg-white p-4 rounded-xl border border-destructive/20 shadow-sm flex justify-between items-center">
                    <div>
                      <div className="flex items-center gap-2 text-sm text-gray-500 mb-1">
                        <Clock className="w-4 h-4" />
                        {alert.createdAt && format(new Date(alert.createdAt), 'PP p')}
                      </div>
                      <div className="font-bold text-gray-900 flex items-center gap-2">
                        User ID: {alert.userId}
                      </div>
                      <div className="text-sm text-gray-600 mt-1 flex items-center gap-1">
                        <MapPin className="w-4 h-4 text-destructive" />
                        {alert.location}
                      </div>
                    </div>
                    <Button 
                      variant="destructive" 
                      onClick={() => resolveSos(alert.id)}
                    >
                      Resolve Alert
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="requests" className="w-full">
          <TabsList className="bg-white border">
            <TabsTrigger value="requests">Help Requests</TabsTrigger>
            <TabsTrigger value="sos">SOS History</TabsTrigger>
          </TabsList>
          
          <TabsContent value="requests" className="mt-6">
            <Card>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {requests?.map((req) => (
                    <TableRow key={req.id}>
                      <TableCell className="font-medium capitalize">
                        {req.type.replace('_', ' ')}
                      </TableCell>
                      <TableCell>
                        <StatusBadge status={req.status} />
                      </TableCell>
                      <TableCell className="text-gray-500 text-sm">
                        {req.createdAt && format(new Date(req.createdAt), 'MMM d, p')}
                      </TableCell>
                      <TableCell className="max-w-xs truncate text-gray-600">
                        {req.description}
                      </TableCell>
                      <TableCell className="text-right">
                        <ActionMenu request={req} />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>

          <TabsContent value="sos" className="mt-6">
            <Card>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Time</TableHead>
                    <TableHead>Location</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {alerts?.map((alert) => (
                    <TableRow key={alert.id}>
                      <TableCell className="font-medium">User #{alert.userId}</TableCell>
                      <TableCell>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          alert.status === 'active' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'
                        }`}>
                          {alert.status}
                        </span>
                      </TableCell>
                      <TableCell className="text-gray-500 text-sm">
                        {alert.createdAt && format(new Date(alert.createdAt), 'MMM d, p')}
                      </TableCell>
                      <TableCell className="text-gray-600 font-mono text-xs">
                        {alert.location}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </LayoutShell>
  );
}

function ActionMenu({ request }: { request: any }) {
  const { mutate } = useUpdateHelpRequestStatus();
  const [open, setOpen] = useState(false);
  const [response, setResponse] = useState(request.adminResponse || "");

  const handleUpdate = (status: "pending" | "in_progress" | "resolved") => {
    mutate({ id: request.id, status, adminResponse: response });
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon">
            <MoreVertical className="w-4 h-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DialogTrigger asChild>
            <DropdownMenuItem>
              <MessageSquare className="w-4 h-4 mr-2" /> Respond & Update
            </DropdownMenuItem>
          </DialogTrigger>
        </DropdownMenuContent>
      </DropdownMenu>

      <DialogContent>
        <DialogHeader>
          <DialogTitle>Update Request #{request.id}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="bg-gray-50 p-3 rounded-lg text-sm text-gray-600">
            {request.description}
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium">Admin Response</label>
            <Textarea 
              value={response} 
              onChange={(e) => setResponse(e.target.value)}
              placeholder="Add a note or response..."
            />
          </div>

          <div className="flex gap-2 justify-end pt-2">
            <Button 
              variant="outline" 
              onClick={() => handleUpdate("in_progress")}
              className="border-blue-200 text-blue-700 hover:bg-blue-50"
            >
              <Clock className="w-4 h-4 mr-2" /> Mark In Progress
            </Button>
            <Button 
              onClick={() => handleUpdate("resolved")}
              className="bg-green-600 hover:bg-green-700"
            >
              <CheckCircle2 className="w-4 h-4 mr-2" /> Resolve Case
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
