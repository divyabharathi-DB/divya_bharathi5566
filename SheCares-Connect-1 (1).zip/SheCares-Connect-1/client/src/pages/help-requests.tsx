import { LayoutShell } from "@/components/layout-shell";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertHelpRequestSchema, type InsertHelpRequest } from "@shared/schema";
import { useCreateHelpRequest, useHelpRequests } from "@/hooks/use-help-requests";
import { StatusBadge } from "@/components/status-badge";
import { format } from "date-fns";
import { Loader2, Send } from "lucide-react";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useState } from "react";

export default function HelpRequests() {
  const { data: requests, isLoading } = useHelpRequests();
  const [open, setOpen] = useState(false);

  return (
    <LayoutShell>
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-display font-bold text-gray-900">Help Requests</h1>
            <p className="text-gray-500 mt-1">Track your cases and submit new reports.</p>
          </div>
          
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button size="lg" className="rounded-full shadow-md">New Request</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>Submit Help Request</DialogTitle>
                <DialogDescription>
                  Provide details about your situation. This is confidential.
                </DialogDescription>
              </DialogHeader>
              <CreateRequestForm onSuccess={() => setOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-4">
          {isLoading ? (
            <div className="text-center py-12 text-gray-500">Loading requests...</div>
          ) : requests?.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-2xl border border-dashed">
              <p className="text-gray-500">You haven't submitted any requests yet.</p>
            </div>
          ) : (
            requests?.map((req) => (
              <div key={req.id} className="bg-white p-6 rounded-2xl border shadow-sm">
                <div className="flex justify-between items-start mb-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-3">
                      <span className="font-bold text-lg text-gray-900 capitalize">
                        {req.type.replace(/_/g, ' ')}
                      </span>
                      <StatusBadge status={req.status} />
                    </div>
                    <div className="text-sm text-gray-500 flex items-center gap-2">
                      <span>ID: #{req.id}</span>
                      <span>•</span>
                      <span>{req.createdAt && format(new Date(req.createdAt), 'PPP p')}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-xl text-gray-700 mb-4">
                  {req.description}
                </div>

                {req.location && (
                  <div className="text-sm text-gray-500 mb-4 flex items-center gap-2">
                    <span className="font-semibold text-gray-700">Location:</span> {req.location}
                  </div>
                )}

                {req.adminResponse && (
                  <div className="border-t pt-4 mt-4">
                    <h4 className="text-sm font-bold text-primary mb-2">Admin Response</h4>
                    <p className="text-sm text-gray-700">{req.adminResponse}</p>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </LayoutShell>
  );
}

function CreateRequestForm({ onSuccess }: { onSuccess: () => void }) {
  const { mutate, isPending } = useCreateHelpRequest();
  
  const form = useForm<InsertHelpRequest>({
    resolver: zodResolver(insertHelpRequestSchema),
    defaultValues: {
      type: "other",
      description: "",
      location: "",
    },
  });

  const onSubmit = (data: InsertHelpRequest) => {
    mutate(data, {
      onSuccess: () => {
        form.reset();
        onSuccess();
      },
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
        <FormField
          control={form.control}
          name="type"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Type of Incident</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="harassment">Harassment</SelectItem>
                  <SelectItem value="domestic_violence">Domestic Violence</SelectItem>
                  <SelectItem value="workplace_issue">Workplace Issue</SelectItem>
                  <SelectItem value="emergency">Emergency</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Describe what happened..." 
                  className="min-h-[100px] resize-none"
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="location"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Location (Optional)</FormLabel>
              <FormControl>
                <Input placeholder="City, Address, or Coordinates" {...field} value={field.value || ""} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button type="submit" className="w-full" disabled={isPending}>
          {isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Submitting...
            </>
          ) : (
            <>
              <Send className="mr-2 h-4 w-4" />
              Submit Request
            </>
          )}
        </Button>
      </form>
    </Form>
  );
}
