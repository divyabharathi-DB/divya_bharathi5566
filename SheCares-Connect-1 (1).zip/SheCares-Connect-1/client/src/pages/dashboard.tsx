import { LayoutShell } from "@/components/layout-shell";
import { useAuth } from "@/hooks/use-auth";
import { SosButton } from "@/components/sos-button";
import { useHelpRequests } from "@/hooks/use-help-requests";
import { StatusBadge } from "@/components/status-badge";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Plus, ArrowRight, MapPin } from "lucide-react";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: requests, isLoading } = useHelpRequests();

  // Sort requests by date descending
  const sortedRequests = requests?.sort((a, b) => 
    new Date(b.createdAt || "").getTime() - new Date(a.createdAt || "").getTime()
  ).slice(0, 3); // Show only recent 3

  return (
    <LayoutShell>
      <div className="space-y-8">
        {/* Welcome Section */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold text-gray-900">
              Welcome back, {user?.firstName}
            </h1>
            <p className="text-gray-500 mt-1">Here is an overview of your safety status.</p>
          </div>
          <Link href="/help">
            <Button className="rounded-full shadow-lg shadow-primary/20">
              <Plus className="w-4 h-4 mr-2" />
              New Request
            </Button>
          </Link>
        </div>

        {/* SOS Section */}
        <section className="bg-white rounded-3xl p-8 border border-red-100 shadow-xl shadow-red-500/5 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-32 bg-red-50 rounded-full blur-3xl opacity-50 -mr-16 -mt-16 pointer-events-none" />
          
          <div className="relative z-10 flex flex-col md:flex-row items-center gap-8 md:gap-16">
            <div className="flex-1 text-center md:text-left">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Emergency Assistance</h2>
              <p className="text-gray-500 mb-6">
                Press the button if you are in immediate danger. We will share your live location with authorities.
              </p>
              <div className="inline-flex items-center gap-2 text-sm text-red-600 bg-red-50 px-3 py-1 rounded-full font-medium">
                <MapPin className="w-4 h-4" /> Location tracking enabled
              </div>
            </div>
            <div className="flex-shrink-0">
              <SosButton />
            </div>
          </div>
        </section>

        {/* Recent Requests */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">Recent Activity</h2>
            <Link href="/help" className="text-sm font-medium text-primary hover:text-primary/80 flex items-center gap-1">
              View all <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid gap-4">
            {isLoading ? (
              [1, 2].map((i) => <Skeleton key={i} className="h-24 w-full rounded-2xl" />)
            ) : sortedRequests?.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-2xl border border-dashed">
                <p className="text-gray-500">No requests found.</p>
                <Link href="/help">
                  <Button variant="link" className="mt-2 text-primary">Create your first request</Button>
                </Link>
              </div>
            ) : (
              sortedRequests?.map((req) => (
                <div key={req.id} className="bg-white p-6 rounded-2xl border hover:border-primary/20 transition-all shadow-sm hover:shadow-md group">
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-medium text-gray-500 uppercase tracking-wider">
                        {req.type.replace('_', ' ')}
                      </span>
                      <StatusBadge status={req.status} />
                    </div>
                    <span className="text-sm text-gray-400">
                      {req.createdAt && format(new Date(req.createdAt), 'MMM d, yyyy')}
                    </span>
                  </div>
                  <p className="text-gray-900 font-medium line-clamp-1 group-hover:text-primary transition-colors">
                    {req.description}
                  </p>
                  {req.adminResponse && (
                    <div className="mt-3 p-3 bg-gray-50 rounded-xl text-sm text-gray-600 border border-gray-100">
                      <span className="font-semibold text-gray-900">Response: </span>
                      {req.adminResponse}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </section>
      </div>
    </LayoutShell>
  );
}
