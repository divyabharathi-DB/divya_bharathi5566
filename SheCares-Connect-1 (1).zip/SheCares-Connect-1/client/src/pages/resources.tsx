import { LayoutShell } from "@/components/layout-shell";
import { useResources } from "@/hooks/use-resources";
import { Skeleton } from "@/components/ui/skeleton";
import { Phone, ExternalLink, ShieldCheck, Scale, Heart } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Resources() {
  const { data: resources, isLoading } = useResources();

  const getIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'legal': return <Scale className="w-5 h-5" />;
      case 'safety': return <ShieldCheck className="w-5 h-5" />;
      default: return <Heart className="w-5 h-5" />;
    }
  };

  return (
    <LayoutShell>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-gray-900">Resources & Guides</h1>
          <p className="text-gray-500 mt-1">Useful information, safety tips, and legal rights.</p>
        </div>

        {/* Featured Emergency Numbers */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { name: "Women's Helpline", number: "1091", desc: "24/7 Emergency Support" },
            { name: "Domestic Violence", number: "181", desc: "Confidential Advice" },
            { name: "Police", number: "100", desc: "Immediate Assistance" },
          ].map((item) => (
            <div key={item.number} className="bg-primary/5 border border-primary/10 rounded-2xl p-6 flex flex-col items-center text-center hover:bg-primary/10 transition-colors cursor-default">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-primary shadow-sm mb-3">
                <Phone className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-gray-900">{item.name}</h3>
              <p className="text-2xl font-display font-bold text-primary my-1">{item.number}</p>
              <p className="text-xs text-gray-500">{item.desc}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            [1, 2, 3, 4, 5].map((i) => (
              <Card key={i} className="overflow-hidden border-none shadow-sm">
                <Skeleton className="h-48 w-full" />
                <div className="p-6 space-y-2">
                  <Skeleton className="h-4 w-1/2" />
                  <Skeleton className="h-4 w-full" />
                </div>
              </Card>
            ))
          ) : resources?.length === 0 ? (
            <div className="col-span-full text-center py-12 text-gray-500">
              No resources available at the moment.
            </div>
          ) : (
            resources?.map((res) => (
              <Card key={res.id} className="hover:shadow-lg transition-all duration-300 border-border/50 hover:border-primary/20 flex flex-col">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <Badge variant="secondary" className="gap-1 pl-2">
                      {getIcon(res.category)}
                      {res.category}
                    </Badge>
                  </div>
                  <CardTitle className="line-clamp-2">{res.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-muted-foreground text-sm line-clamp-4 leading-relaxed">
                    {res.content}
                  </p>
                </CardContent>
                {res.contactNumber && (
                  <CardFooter className="bg-gray-50/50 border-t p-4">
                    <div className="flex items-center gap-2 text-sm font-medium text-primary w-full">
                      <Phone className="w-4 h-4" />
                      {res.contactNumber}
                      <Button size="icon" variant="ghost" className="ml-auto h-8 w-8">
                        <ExternalLink className="w-4 h-4 text-gray-400" />
                      </Button>
                    </div>
                  </CardFooter>
                )}
              </Card>
            ))
          )}
        </div>
      </div>
    </LayoutShell>
  );
}
