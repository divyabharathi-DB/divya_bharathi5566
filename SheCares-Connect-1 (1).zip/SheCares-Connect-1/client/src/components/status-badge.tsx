import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Clock, AlertCircle } from "lucide-react";

export function StatusBadge({ status }: { status: string }) {
  if (status === "resolved") {
    return (
      <Badge className="bg-green-100 text-green-700 hover:bg-green-200 border-green-200 gap-1 pl-2">
        <CheckCircle2 className="w-3 h-3" /> Resolved
      </Badge>
    );
  }
  if (status === "in_progress") {
    return (
      <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-200 border-blue-200 gap-1 pl-2">
        <Clock className="w-3 h-3" /> In Progress
      </Badge>
    );
  }
  return (
    <Badge className="bg-yellow-100 text-yellow-700 hover:bg-yellow-200 border-yellow-200 gap-1 pl-2">
      <AlertCircle className="w-3 h-3" /> Pending
    </Badge>
  );
}
