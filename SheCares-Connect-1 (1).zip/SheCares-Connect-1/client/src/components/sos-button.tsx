import { useState } from "react";
import { AlertTriangle, Loader2 } from "lucide-react";
import { useTriggerSos } from "@/hooks/use-sos";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";

export function SosButton({ variant = "full" }: { variant?: "full" | "compact" }) {
  const { mutate, isPending } = useTriggerSos();
  const [open, setOpen] = useState(false);
  const { user } = useAuth();

  const handleTrigger = () => {
    if (!navigator.geolocation) {
      mutate({ location: "Location unavailable" });
      setOpen(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        mutate({ location: `Lat: ${latitude}, Long: ${longitude}` });
        setOpen(false);
      },
      (error) => {
        console.error(error);
        mutate({ location: "Location denied by user" });
        setOpen(false);
      }
    );
  };

  if (variant === "compact") {
    return (
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button variant="destructive" size="sm" className="gap-2 font-bold animate-pulse">
            <AlertTriangle className="w-4 h-4" /> SOS
          </Button>
        </DialogTrigger>
        <Content handleTrigger={handleTrigger} isPending={isPending} />
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button 
          className="group relative w-full aspect-square max-w-[280px] mx-auto rounded-full bg-gradient-to-br from-red-500 to-red-600 shadow-xl shadow-red-500/30 flex flex-col items-center justify-center text-white transition-all duration-300 hover:scale-105 active:scale-95 sos-pulse"
        >
          <div className="absolute inset-4 rounded-full border-2 border-white/20 group-hover:border-white/40 transition-colors" />
          <AlertTriangle className="w-20 h-20 mb-4 drop-shadow-md" />
          <span className="text-3xl font-black tracking-widest font-display">SOS</span>
          <span className="text-sm font-medium mt-1 opacity-90 uppercase tracking-wide">Emergency Alert</span>
        </button>
      </DialogTrigger>
      <Content handleTrigger={handleTrigger} isPending={isPending} />
    </Dialog>
  );
}

function Content({ handleTrigger, isPending }: { handleTrigger: () => void, isPending: boolean }) {
  return (
    <DialogContent className="sm:max-w-md border-destructive/20 bg-red-50">
      <DialogHeader>
        <DialogTitle className="text-destructive flex items-center gap-2 text-2xl">
          <AlertTriangle className="w-6 h-6" />
          Confirm Emergency
        </DialogTitle>
        <DialogDescription className="text-base text-gray-700 pt-2">
          This will alert local authorities and your emergency contacts with your current location. 
          <br /><br />
          <strong>Only use this in case of immediate danger.</strong>
        </DialogDescription>
      </DialogHeader>
      <DialogFooter className="gap-2 sm:gap-0 mt-4">
        <DialogClose asChild>
          <Button variant="ghost" className="h-12">Cancel</Button>
        </DialogClose>
        <Button 
          variant="destructive" 
          onClick={handleTrigger} 
          disabled={isPending}
          className="h-12 px-8 font-bold text-lg shadow-lg shadow-red-500/20"
        >
          {isPending ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Sending Alert...
            </>
          ) : (
            "YES, SEND HELP"
          )}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}
