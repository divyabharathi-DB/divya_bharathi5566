import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertHelpRequest, type HelpRequest } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useHelpRequests() {
  return useQuery({
    queryKey: [api.helpRequests.list.path],
    queryFn: async () => {
      const res = await fetch(api.helpRequests.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch help requests");
      return api.helpRequests.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateHelpRequest() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertHelpRequest) => {
      const res = await fetch(api.helpRequests.create.path, {
        method: api.helpRequests.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 401) throw new Error("Unauthorized");
        const error = await res.json();
        throw new Error(error.message || "Failed to submit request");
      }
      return api.helpRequests.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.helpRequests.list.path] });
      toast({
        title: "Request Submitted",
        description: "Help is on the way. We have received your request.",
        variant: "default",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useUpdateHelpRequestStatus() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, status, adminResponse }: { id: number; status: "pending" | "in_progress" | "resolved"; adminResponse?: string }) => {
      const url = buildUrl(api.helpRequests.updateStatus.path, { id });
      const res = await fetch(url, {
        method: api.helpRequests.updateStatus.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status, adminResponse }),
        credentials: "include",
      });

      if (!res.ok) throw new Error("Failed to update status");
      return api.helpRequests.updateStatus.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.helpRequests.list.path] });
      toast({ title: "Status Updated" });
    },
  });
}
