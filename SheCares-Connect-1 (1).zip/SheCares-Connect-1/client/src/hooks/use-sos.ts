import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertSosAlert } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useSosAlerts() {
  return useQuery({
    queryKey: [api.sos.list.path],
    queryFn: async () => {
      const res = await fetch(api.sos.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch SOS alerts");
      return api.sos.list.responses[200].parse(await res.json());
    },
  });
}

export function useTriggerSos() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertSosAlert) => {
      const res = await fetch(api.sos.create.path, {
        method: api.sos.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });

      if (!res.ok) throw new Error("Failed to trigger SOS");
      return api.sos.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.sos.list.path] });
      toast({
        title: "EMERGENCY ALERT SENT",
        description: "Authorities and contacts have been notified with your location.",
        variant: "destructive",
        duration: 10000,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "SOS Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useResolveSos() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.sos.resolve.path, { id });
      const res = await fetch(url, {
        method: api.sos.resolve.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to resolve SOS");
      return api.sos.resolve.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.sos.list.path] });
      toast({ title: "Alert Resolved" });
    },
  });
}
